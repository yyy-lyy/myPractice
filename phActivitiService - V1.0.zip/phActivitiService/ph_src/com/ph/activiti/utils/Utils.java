package com.ph.activiti.utils;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
 * 其他相关工具
 * @author yangyunyun
 *
 */
public class Utils {

	/**
	 * bean 转换成Map
	 * @param obj ：待转换的ｂｅａｎ
	 * @return
	 * @throws Exception
	 */
	public static Map<String, Object> bean2Map(Object obj) throws Exception {
		
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
			PropertyDescriptor[] propertyDescriptors = beanInfo
					.getPropertyDescriptors();

			for (PropertyDescriptor property : propertyDescriptors) {
				String key = property.getName();

				// 过滤class属性
				if (!key.equals("class")) {
					// 得到property对应的getter方法
					Method getter = property.getReadMethod();
					Object value = getter.invoke(obj);

					map.put(key, value);
				}
			}
		} catch (Exception e) {
			System.out.println("bean2Map Error " + e);
			throw e;
		}
		return map;
	}
	
	/**
	 * 将 Map 转换成bean
	 * @param map ：待转换的 map
	 * @param obj ：转换后的对象
	 * @throws Exception
	 */
	public static void map2Bean(Map<String, Object> map, Object obj) throws Exception {
		try {
			BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
			PropertyDescriptor[] propertyDescriptors = beanInfo
					.getPropertyDescriptors();
			for (PropertyDescriptor property : propertyDescriptors) {
				String key = property.getName();

				if (map.containsKey(key)) {
					Object value = map.get(key);
					// 得到property对应的setter方法
					Method setter = property.getWriteMethod();
					setter.invoke(obj, value);
				}
			}
		} catch (Exception e) {
			System.out.println("map2Bean Error " + e);
			throw e;
		}
	}
}
