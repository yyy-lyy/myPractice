package com.ph.activiti.utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * 分页类
 * @author yangyunyun
 * <br>2017年3月20日
 */
public class Page<T> implements Serializable{
	
	private static final long serialVersionUID = 1L;
	//当前页码
	private int currentPage; 
	//每页显示记录条数,设置为“-1”表示不进行分页（分页无效）
	private int rows; 
	// 总记录数，设置为“-1”表示不查询总数
	private long count;
	//总共页数
	private int allPageNum;
	//起始下标
	private int startIndex;
	
	
	private List<T> list = new ArrayList<T>();
	
	public Page(){
		super();
	}
	
	public Page(int currentPage, int rows, int count){
		if(currentPage <=1){
			currentPage = 1;
		}
		this.rows = rows;
		this.count = count;
		
		//计算获取数据的起始位置和结束为止
		//计算总页数
		if(count <= rows){
			this.allPageNum = 1;
			this.currentPage = 1;
			
			startIndex = 0;
		}else{
			this.allPageNum = count%rows == 0?  count/rows : (count/rows)+1;
			if(currentPage >= allPageNum){
				this.currentPage = allPageNum;
			}else{
				this.currentPage = currentPage;
			}
			startIndex = this.currentPage*rows - rows;
		}
	}



	public int getCurrentPage() {
		return currentPage;
	}



	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}



	public int getRows() {
		return rows;
	}



	public void setRows(int rows) {
		this.rows = rows;
	}



	public long getCount() {
		return count;
	}



	public void setCount(long count) {
		this.count = count;
	}



	public int getAllPageNum() {
		return allPageNum;
	}



	public void setAllPageNum(int allPageNum) {
		this.allPageNum = allPageNum;
	}



	public int getStartIndex() {
		return startIndex;
	}



	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}



	public List<T> getList() {
		return list;
	}



	public void setList(List<T> list) {
		this.list = list;
	}
	
	

}