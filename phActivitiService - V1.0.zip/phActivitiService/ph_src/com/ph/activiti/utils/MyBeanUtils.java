package com.ph.activiti.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.impl.persistence.entity.ExecutionEntity;
import org.activiti.engine.impl.persistence.entity.HistoricProcessInstanceEntity;
import org.activiti.engine.impl.persistence.entity.HistoricTaskInstanceEntity;
import org.activiti.engine.impl.persistence.entity.HistoricVariableInstanceEntity;
import org.activiti.engine.impl.persistence.entity.IdentityLinkEntity;
import org.activiti.engine.impl.persistence.entity.ProcessDefinitionEntity;
import org.activiti.engine.impl.persistence.entity.TaskEntity;
import org.activiti.engine.impl.persistence.entity.VariableInstance;
import org.activiti.engine.impl.persistence.entity.VariableInstanceEntity;
import org.activiti.engine.impl.pvm.process.ActivityImpl;
import org.activiti.engine.impl.pvm.process.ProcessDefinitionImpl;
import org.activiti.engine.impl.pvm.process.TransitionImpl;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;

import com.ph.activiti.vo.ActivityVo;
import com.ph.activiti.vo.ProcessDefinitionVo;
import com.ph.activiti.vo.ProcessInstanceVo;
import com.ph.activiti.vo.TaskVo;
import com.ph.activiti.vo.TransitionVo;
import com.ph.activiti.vo.VariableVo;

/**
 * 此工具类用于将 Activiti 中的类中的属性转换到自定义的Vo中
 * 
 * @author yangyunyun
 *
 */
public class MyBeanUtils {

	public static void madeProcessInstanceVo(ProcessInstance pi,
			ProcessInstanceVo vo) {
		if (vo == null || "".equals(vo)) {
			vo = new ProcessInstanceVo();
		}
		ExecutionEntity processInstance = (ExecutionEntity) pi;

		vo.setName(processInstance.getName());
		try {
			ExecutionEntity parent = processInstance.getParent();
			if (parent != null) {
				ProcessInstanceVo pVo = new ProcessInstanceVo();
				madeProcessInstanceVo(parent, pVo);
				vo.setParent(pVo);
			}
		} catch (Exception e) {
		}
		// vo.setEndActivityId(processInstance.getEndActivityId());
		// vo.setStartTime(processInstance.getStartTime());
		// vo.setScope(processInstance.getScope());
		ExecutionEntity replacedBy = processInstance.getReplacedBy();
		if (replacedBy != null) {
			ProcessInstanceVo pVo = new ProcessInstanceVo();
			madeProcessInstanceVo(replacedBy, pVo);
			vo.setReplacedBy(pVo);
		}
		// vo.setOperating(processInstance.getOperating());
		// vo.setEndTime(processInstance.getEndTime());
		try {

			ActivityImpl activity = processInstance.getActivity();
			if (activity != null) {
				ActivityVo aVo = new ActivityVo();
				madeActivityVo(activity, aVo);
				vo.setActivity(aVo);
			}
		} catch (Exception e) {
		}
		try {
			TransitionImpl transition = processInstance.getTransition();
			if (transition != null) {
				TransitionVo tVo = new TransitionVo();
				madeTransitionVo(transition, tVo);
				vo.setTransition(tVo);
			}

		} catch (Exception e) {
		}

		// vo.setActive(processInstance.getActive());
		// vo.setConcurrent(processInstance.getConcurrent());
		// vo.setEnded(processInstance.getEnded());
		try {

			List<ExecutionEntity> executions = processInstance.getExecutions();
			if (executions != null && executions.size() > 0) {
				List<ProcessInstanceVo> list = new ArrayList<>();
				for (ExecutionEntity e : executions) {
					ProcessInstanceVo pVo = new ProcessInstanceVo();
					madeProcessInstanceVo(e, pVo);
					list.add(pVo);
				}
				vo.setExecutions(list);
			}
		} catch (Exception e) {
		}
		// vo.setEventScope(processInstance.getEventScope());
		vo.setEventName(processInstance.getEventName());
		vo.setId(processInstance.getId());
//		try {
//
//			List<TaskEntity> tasks = processInstance.getTasks();
//			if (tasks != null && tasks.size() > 0) {
//				List<TaskVo> list = new ArrayList<>();
//				for (TaskEntity t : tasks) {
//					TaskVo tVo = new TaskVo();
//					madeTaskVo(t, tVo);
//					list.add(tVo);
//				}
//				vo.setTasks(list);
//			}
//		} catch (Exception e) {
//		}
		vo.setLockTime(processInstance.getLockTime());
		vo.setTenantId(processInstance.getTenantId());
		// vo.setDeleteRoot(processInstance.getDeleteRoot());
		try {

			TransitionImpl transitionImpl = processInstance
					.getTransitionBeingTaken();
			if (transitionImpl != null) {
				TransitionVo transitionVo = new TransitionVo();
				madeTransitionVo(transitionImpl, transitionVo);
				vo.setTransitionBeingTaken(transitionVo);
			}
		} catch (Exception e) {
		}

		// vo.setStartUserId(processInstance.getStartUserId());
		// vo.setStartActivityId(processInstance.getStartActivityId());
		// StartingExecution execution = processInstance.getStartingExecution();
		// if(execution != null){
		//
		// com.ph.activiti.vo.StartingExecution startingExecution = new
		// com.ph.activiti.vo.StartingExecution();
		// vo.setStartingExecution(startingExecution);
		// }
		vo.setLocalizedDescription(processInstance.getLocalizedDescription());
		vo.setCachedEntityState(processInstance.getCachedEntityState());
//		try {
//
//			ExecutionEntity instance = processInstance.getProcessInstance();
//			if (instance != null) {
//				ProcessInstanceVo pVo = new ProcessInstanceVo();
//				madeProcessInstanceVo(instance, pVo);
//				vo.setProcessInstance(pVo);
//			}
//		} catch (Exception e) {
//		}
		try {

			ExecutionEntity execution2 = processInstance.getSuperExecution();
			if (execution2 != null) {
				ProcessInstanceVo pVo = new ProcessInstanceVo();
				madeProcessInstanceVo(execution2, pVo);
				vo.setSuperExecution(pVo);
			}
		} catch (Exception e) {
		}
		// vo.setSuperProcessInstanceId(processInstance.getSuperProcessInstanceId());
		try {

			ProcessDefinitionImpl processDefinition = processInstance
					.getProcessDefinition();
			if (processDefinition != null) {
				ProcessDefinitionVo pVo = new ProcessDefinitionVo();
				madeProcessDefinitionVo(processDefinition, pVo);
				vo.setProcessDefinition(pVo);
			}
		} catch (Exception e) {
		}
		try {

			ExecutionEntity instance2 = processInstance.getSubProcessInstance();
			if (instance2 != null) {
				ProcessInstanceVo pVo = new ProcessInstanceVo();
				madeProcessInstanceVo(instance2, pVo);
				vo.setSubProcessInstance(pVo);
			}
		} catch (Exception e) {
		}
		vo.setLocalizedName(processInstance.getLocalizedName());

		try {

			Map<String, VariableInstance> variableInstances = processInstance
					.getVariableInstances();
			if (variableInstances != null) {
				Set<String> keySet = variableInstances.keySet();

				if (!keySet.isEmpty()) {
					Map<String, VariableVo> map = new HashMap<>();
					Iterator<String> it = keySet.iterator();
					while (it.hasNext()) {
						String key = it.next();
						VariableInstance variableInstance = variableInstances
								.get(key);
						VariableVo vvo = new VariableVo();
						madeVariableVo(variableInstance, vvo);
						map.put(key, vvo);
					}
					vo.setVariableInstances(map);
				}
			}
		} catch (Exception e) {
		}
		vo.setExecutionListenerIndex(processInstance
				.getExecutionListenerIndex());
//		try {
//
//			List<IdentityLinkEntity> identityLinks = processInstance
//					.getIdentityLinks();
//			if (identityLinks != null && identityLinks.size() > 0) {
//				List<com.ph.activiti.vo.IdentityLinkEntity> list = new ArrayList<>();
//				for (IdentityLinkEntity t : identityLinks) {
//					com.ph.activiti.vo.IdentityLinkEntity iVo = new com.ph.activiti.vo.IdentityLinkEntity();
//					madeIdentityLinkEntity(t, iVo);
//					list.add(iVo);
//				}
//				vo.setIdentityLinks(list);
//			}
//		} catch (Exception e) {
//		}
		vo.setDescription(processInstance.getDescription());
		// vo.setDurationInMillis(processInstance.getDurationInMillis());
		try {

			Map<String, VariableInstanceEntity> variablesCache = processInstance
					.getUsedVariablesCache();
			if (variablesCache != null) {
				Set<String> keySet = variablesCache.keySet();

				if (!keySet.isEmpty()) {
					Map<String, VariableVo> map = new HashMap<>();
					Iterator<String> it = keySet.iterator();
					while (it.hasNext()) {
						String key = it.next();
						VariableInstanceEntity variableInstance = variablesCache
								.get(key);
						VariableVo vvo = new VariableVo();
						madeVariableVo(variableInstance, vvo);
						map.put(key, vvo);
					}
					vo.setUsedVariablesCache(map);
				}
			}
		} catch (Exception e) {
		}
		try {

			List<VariableInstanceEntity> variables = processInstance
					.getQueryVariables();
			if (variables != null && variables.size() > 0) {
				List<VariableVo> list = new ArrayList<>();
				for (VariableInstanceEntity v : variables) {
					VariableVo vvo = new VariableVo();
					madeVariableVo(v, vvo);
					list.add(vvo);
				}
				vo.setQueryVariables(list);
			}
		} catch (Exception e) {
		}
		// vo.setForcedUpdate(processInstance.getForcedUpdate());
		vo.setProcessDefinitionVersion(processInstance
				.getProcessDefinitionVersion());
		vo.setProcessDefinitionKey(processInstance.getProcessDefinitionKey());
		vo.setSuperExecutionId(processInstance.getSuperExecutionId());
		vo.setBusinessKey(processInstance.getBusinessKey());
		vo.setDeleteReason(processInstance.getDeleteReason());
		vo.setProcessDefinitionId(processInstance.getProcessDefinitionId());
		vo.setDeploymentId(processInstance.getDeploymentId());
		// vo.setActivityName(processInstance.getActivityName());
		vo.setProcessDefinitionName(processInstance.getProcessDefinitionName());
		vo.setProcessInstanceId(processInstance.getProcessInstanceId());
		vo.setActivityId(processInstance.getActivityId());
		vo.setRevision(processInstance.getRevision());
		vo.setParentId(processInstance.getParentId());
	}

	public static void madeIdentityLinkEntity(IdentityLinkEntity t,
			com.ph.activiti.vo.IdentityLinkEntity iVo) {
		if (iVo == null || "".equals(iVo)) {
			iVo = new com.ph.activiti.vo.IdentityLinkEntity();
		}
		iVo.setProcessInstanceId(t.getProcessInstanceId());
		iVo.setProcessDefId(t.getProcessDefId());
//		try {
//
//			ExecutionEntity processInstance = t.getProcessInstance();
//			if (processInstance != null) {
//				ProcessInstanceVo pVo = new ProcessInstanceVo();
//				madeProcessInstanceVo(processInstance, pVo);
//				iVo.setProcessInstance(pVo);
//			}
//		} catch (Exception e) {
//		}
		iVo.setType(t.getType());
		iVo.setUserId(t.getUserId());
		iVo.setTaskId(t.getTaskId());
		iVo.setId(t.getId());
		iVo.setGroupId(t.getGroupId());
		try {

			ProcessDefinitionImpl processDef = t.getProcessDef();
			if (processDef != null) {
				ProcessDefinitionVo pVo = new ProcessDefinitionVo();
				madeProcessDefinitionVo(processDef, pVo);
				iVo.setProcessDef(pVo);
			}
		} catch (Exception e) {
		}
		try {

			TaskEntity task = t.getTask();
			if (task != null) {
				TaskVo tVo = new TaskVo();
				madeTaskVo(task, tVo);
				iVo.setTask(tVo);
			}
		} catch (Exception e) {
		}
	}

	public static void madeVariableVo(VariableInstance variableInstance,
			VariableVo vvo) {
		if (vvo == null || "".equals(vvo)) {
			vvo = new VariableVo();
		}
		vvo.setName(variableInstance.getName());
		vvo.setDoubleValue(variableInstance.getDoubleValue());
		vvo.setExecutionId(variableInstance.getExecutionId());
		// vvo.setVariableType(variableInstance.getVariableType());
		vvo.setProcessInstanceId(variableInstance.getProcessInstanceId());
		// vvo.setLastUpdatedTime(variableInstance.getLastUpdatedTime());
		vvo.setLocalizedName(variableInstance.getLocalizedName());
		// vvo.setForcedUpdate(variableInstance.getForcedUpdate());
		vvo.setCachedValue(variableInstance.getCachedValue());
		vvo.setLocalizedDescription(variableInstance.getLocalizedDescription());
		// vvo.setCreateTime(variableInstance.getCreateTime());
		// vvo.setDeleted(variableInstance.getDeleted());
		vvo.setLongValue(variableInstance.getLongValue());
		vvo.setRevision(variableInstance.getRevision());
		vvo.setId(variableInstance.getId());
		// vvo.setType(variableInstance.getType());
		vvo.setTextValue2(variableInstance.getTextValue2());
		vvo.setTypeName(variableInstance.getTypeName());
		vvo.setTextValue(variableInstance.getTextValue());
		vvo.setTaskId(variableInstance.getTaskId());
	}

	public static void madeProcessDefinitionVo(ProcessDefinitionImpl pf,
			ProcessDefinitionVo pVo) {
		if (pVo == null || "".equals(pVo)) {
			pVo = new ProcessDefinitionVo();
		}
		ProcessDefinitionEntity processDefinition = (ProcessDefinitionEntity) pf;

		pVo.setProperties(processDefinition.getProperties());
		pVo.setName(processDefinition.getName());
		pVo.setDeploymentId(processDefinition.getDeploymentId());
		// pVo.setIdentityLinksInitialized(processDefinition.getIdentityLinksInitialized());
		// pVo.setGraphicalNotationDefined(processDefinition.getGraphicalNotationDefined());
		pVo.setSuspensionState(processDefinition.getSuspensionState());
		pVo.setDiagramResourceName(processDefinition.getDiagramResourceName());
		pVo.setDescription(processDefinition.getDescription());
		pVo.setHistoryLevel(processDefinition.getHistoryLevel());
		pVo.setResourceName(processDefinition.getResourceName());
		pVo.setHasStartFormKey(processDefinition.getHasStartFormKey());
		pVo.setVariables(processDefinition.getVariables());
		pVo.setKey(processDefinition.getKey());
		pVo.setVersion(processDefinition.getVersion());
		pVo.setCategory(processDefinition.getCategory());
		pVo.setTenantId(processDefinition.getTenantId());
		pVo.setRevision(processDefinition.getRevision());
		pVo.setId(processDefinition.getId());
	}

	public static void madeTaskVo(Task task, TaskVo tVo) {
		if (tVo == null || "".equals(tVo)) {
			tVo = new TaskVo();
		}

		TaskEntity t = (TaskEntity) task;

		tVo.setId(t.getId());
		tVo.setPriority(t.getPriority());
		tVo.setName(t.getName());
		// tVo.setLocalizedDescription(t.getLocalizedDescription());
		// tVo.setLocalizedName(t.getLocalizedName());
		// tVo.setInitialAssignee(t.getInitialAssignee());
		tVo.setParentTaskId(t.getParentTaskId());
		tVo.setDescription(t.getDescription());
		tVo.setEventName(t.getEventName());
		tVo.setCreateTime(t.getCreateTime());
		tVo.setFormKey(t.getFormKey());

		try {
			ExecutionEntity processInstance = t.getExecution();
			if (processInstance != null) {
				ProcessInstanceVo pVo = new ProcessInstanceVo();
				madeProcessInstanceVo(processInstance, pVo);
				tVo.setExecution(pVo);
			}
		} catch (Exception e) {
		}

		tVo.setOwner(t.getOwner());
		tVo.setAssignee(t.getAssignee());
		tVo.setRevision(t.getRevision());
		tVo.setTenantId(t.getTenantId());
		// tVo.setDeleted(t.getDeleted());
		tVo.setCategory(t.getCategory());
		tVo.setDueDate(t.getDueDate());
		// tVo.setTaskIdentityLinkEntities(t.getTaskIdentityLinkEntities());
		try {
			ExecutionEntity instance = t.getProcessInstance();
			if (instance != null) {
				ProcessInstanceVo pVo = new ProcessInstanceVo();
				madeProcessInstanceVo(instance, pVo);
				tVo.setProcessInstance(pVo);
			}
		} catch (Exception e) {
		}
		tVo.setTaskDefinitionKey(t.getTaskDefinitionKey());
		// tVo.setForcedUpdate(t.getForcedUpdate());
		tVo.setProcessDefinitionId(t.getProcessDefinitionId());
		tVo.setExecutionId(t.getExecutionId());
		try {
			List<VariableInstanceEntity> variables = t.getQueryVariables();
			if (variables != null && variables.size() > 0) {
				List<VariableVo> list = new ArrayList<>();
				for (VariableInstanceEntity v : variables) {
					VariableVo vvo = new VariableVo();
					madeVariableVo(v, vvo);
					list.add(vvo);
				}
				tVo.setQueryVariables(list);
			}
		} catch (Exception e) {
		}
		tVo.setProcessInstanceId(t.getProcessInstanceId());
		// tVo.setIdentityLinksInitialized(t.getIdentityLinksInitialized());

	}

	public static void madeTaskVo(HistoricTaskInstance tsie, TaskVo tVo) {
		if (tVo == null || "".equals(tVo)) {
			tVo = new TaskVo();
		}
		HistoricTaskInstanceEntity t = (HistoricTaskInstanceEntity) tsie;

		tVo.setPriority(t.getPriority());
		tVo.setName(t.getName());
		tVo.setParentTaskId(t.getParentTaskId());
		tVo.setDescription(t.getDescription());
		tVo.setProcessDefinitionName(t.getProcessDefinitionName());
		tVo.setProcessInstanceId(t.getProcessInstanceId());
		tVo.setProcessDefinitionId(t.getProcessDefinitionId());
		try {

			List<HistoricVariableInstanceEntity> variables = t
					.getQueryVariables();
			if (variables != null && variables.size() > 0) {
				List<VariableVo> list = new ArrayList<>();
				for (HistoricVariableInstanceEntity v : variables) {
					VariableVo vvo = new VariableVo();
					madeVariableVo(v, vvo);
					list.add(vvo);
				}
				tVo.setQueryVariables(list);
			}
		} catch (Exception e) {
		}
		tVo.setProcessDefinitionKey(t.getProcessDefinitionKey());
		tVo.setDeleteReason(t.getDeleteReason());
		tVo.setProcessDefinitionVersion(t.getProcessDefinitionVersion());
		tVo.setExecutionId(t.getExecutionId());
		tVo.setTaskDefinitionKey(t.getTaskDefinitionKey());
		tVo.setDeploymentId(t.getDeploymentId());
		tVo.setDurationInMillis(t.getDurationInMillis());
		tVo.setOwner(t.getOwner());
		tVo.setAssignee(t.getAssignee());
		tVo.setCreateTime(t.getCreateTime());
		tVo.setDueDate(t.getDueDate());
		tVo.setId(t.getId());
		tVo.setStartTime(t.getStartTime());
		tVo.setEndTime(t.getEndTime());
		tVo.setCategory(t.getCategory());
		tVo.setFormKey(t.getFormKey());
		tVo.setTenantId(t.getTenantId());
	}

	public static void madeTransitionVo(TransitionImpl transition,
			TransitionVo tVo) {

		if (tVo == null || "".equals(tVo)) {
			tVo = new TransitionVo();
		}
		try {

			ActivityImpl activity = transition.getDestination();
			if (activity != null) {
				ActivityVo aVo = new ActivityVo();
				madeActivityVo(activity, aVo);
				tVo.setDestination(aVo);
			}
		} catch (Exception e) {
		}
		try {

			ActivityImpl source = transition.getSource();
			if (source != null) {
				ActivityVo aVo = new ActivityVo();
				madeActivityVo(source, aVo);
				tVo.setSource(aVo);
			}
		} catch (Exception e) {
		}

		tVo.setWaypoints(transition.getWaypoints());

	}

	public static void madeActivityVo(ActivityImpl activity, ActivityVo aVo) {

		if (aVo == null || "".equals(aVo)) {
			aVo = new ActivityVo();
		}
//		aVo.setProperties(activity.getProperties());
		// aVo.setParent(activity.getParent());
		// aVo.setOutgoingTransitions(activity.getOutgoingTransitions());
		// aVo.setIncomingTransitions(activity.getIncomingTransitions());
		// aVo.setNamedOutgoingTransitions(activity.getNamedOutgoingTransitions());
		try {

			ProcessDefinitionImpl processDefinition = activity
					.getProcessDefinition();
			if (processDefinition != null) {
				ProcessDefinitionVo pVo = new ProcessDefinitionVo();
				madeProcessDefinitionVo(processDefinition, pVo);
				aVo.setProcessDefinition(pVo);
			}

		} catch (Exception e) {
		}

		// aVo.setNamedActivities(activity.getNamedActivities());

		aVo.setFailedJobRetryTimeCycleValue(activity
				.getFailedJobRetryTimeCycleValue());
		aVo.setY(activity.getY());
		// aVo.setScope(activity.getScope());
		// aVo.setAsync(activity.getAsync());
		aVo.setId(activity.getId());
		aVo.setVariables(activity.getVariables());
		try {

			List<ActivityImpl> activities = activity.getActivities();
			if (activities != null && activities.size() > 0) {
				List<ActivityVo> list = new ArrayList<>();
				for (ActivityImpl ai : activities) {
					ActivityVo acVo = new ActivityVo();
					madeActivityVo(ai, acVo);
					list.add(acVo);
				}
				aVo.setActivities(list);
			}
		} catch (Exception e) {
		}
		aVo.setWidth(activity.getWidth());
		aVo.setHeight(activity.getHeight());
		// aVo.setExclusive(activity.getExclusive());
		aVo.setX(activity.getX());

	}

	public static void madeProcessInstanceVo(HistoricProcessInstance pi,
			ProcessInstanceVo vo) {
		if (vo == null || "".equals(vo)) {
			vo = new ProcessInstanceVo();
		}
		HistoricProcessInstanceEntity processInstance = (HistoricProcessInstanceEntity) pi;

		vo.setName(processInstance.getName());
		// vo.setParent(processInstance.getParent());
		vo.setEndActivityId(processInstance.getEndActivityId());
		vo.setStartTime(processInstance.getStartTime());
		// vo.setScope(processInstance.getScope());
		// vo.setReplacedBy(processInstance.getReplacedBy());
		// vo.setOperating(processInstance.getOperating());
		vo.setEndTime(processInstance.getEndTime());
		// vo.setActivity(processInstance.getActivity());
		// vo.setTransition(processInstance.getTransition());
		// vo.setActive(processInstance.getActive());
		// vo.setConcurrent(processInstance.getConcurrent());
		// vo.setEnded(processInstance.getEnded());
		// vo.setExecutions(processInstance.getExecutions());
		// vo.setEventScope(processInstance.getEventScope());
		// vo.setEventName(processInstance.getEventName());
		vo.setId(processInstance.getId());
		// vo.setTasks(processInstance.getTasks());
		// vo.setLockTime(processInstance.getLockTime());
		vo.setTenantId(processInstance.getTenantId());
		// vo.setDeleteRoot(processInstance.getDeleteRoot());
		// vo.setTransitionBeingTaken(processInstance.getTransitionBeingTaken());
		vo.setStartUserId(processInstance.getStartUserId());
		vo.setStartActivityId(processInstance.getStartActivityId());
		// vo.setStartingExecution(processInstance.getStartingExecution());
		vo.setLocalizedDescription(processInstance.getLocalizedDescription());
		// vo.setCachedEntityState(processInstance.getCachedEntityState());
		// vo.setProcessInstance(processInstance.getProcessInstance());
		// vo.setSuperExecution(processInstance.getSuperExecution());
		vo.setSuperProcessInstanceId(processInstance
				.getSuperProcessInstanceId());
		// vo.setProcessDefinition(processInstance.getProcessDefinition());
		// vo.setSubProcessInstance(processInstance.getSubProcessInstance());
		vo.setLocalizedName(processInstance.getLocalizedName());
		// vo.setVariableInstances(processInstance.getVariableInstances());
		// vo.setExecutionListenerIndex(processInstance.getExecutionListenerIndex());
		// vo.setIdentityLinks(processInstance.getIdentityLinks());
		vo.setDescription(processInstance.getDescription());
		vo.setDurationInMillis(processInstance.getDurationInMillis());
		// vo.setUsedVariablesCache(processInstance.getUsedVariablesCache());
		try {

			List<HistoricVariableInstanceEntity> variables = processInstance
					.getQueryVariables();
			List<VariableVo> vos = new ArrayList<>();
			if (variables != null && variables.size() > 0) {
				for (HistoricVariableInstanceEntity v : variables) {
					VariableVo vvo = new VariableVo();
					madeVariableVo(v, vvo);
					vos.add(vvo);
				}
				vo.setQueryVariables(vos);
			}
		} catch (Exception e) {
		}
		// vo.setForcedUpdate(processInstance.getForcedUpdate());
		vo.setProcessDefinitionVersion(processInstance
				.getProcessDefinitionVersion());
		vo.setProcessDefinitionKey(processInstance.getProcessDefinitionKey());
		// vo.setSuperExecutionId(processInstance.getSuperExecutionId());
		vo.setBusinessKey(processInstance.getBusinessKey());
		vo.setDeleteReason(processInstance.getDeleteReason());
		vo.setProcessDefinitionId(processInstance.getProcessDefinitionId());
		vo.setDeploymentId(processInstance.getDeploymentId());
		// vo.setActivityName(processInstance.getActivityName());
		vo.setProcessDefinitionName(processInstance.getProcessDefinitionName());
		vo.setProcessInstanceId(processInstance.getProcessInstanceId());
		// vo.setActivityId(processInstance.getActivityId());
		// vo.setRevision(processInstance.getRevision());
		// vo.setParentId(processInstance.getParentId());

		// vo.setEndActivityId(processInstance.getEndActivityId());
		// vo.setBusinessKey(processInstance.getBusinessKey());
		// vo.setStartUserId(processInstance.getStartUserId());
		// vo.setStartActivityId(processInstance.getStartActivityId());
		// vo.setSuperProcessInstanceId(processInstance.getSuperProcessInstanceId());
		// vo.setTenantId(processInstance.getTenantId());
		// vo.setName(processInstance.getName());
		// // vo.setLocalizedName(processInstance.get);
		// vo.setDescription(processInstance.getDescription());
		// // vo.setLocalizedDescription(processInstance.getl);
		// // vo.setQueryVariables(processInstance.getProcessVariables());
		// vo.setId(processInstance.getId());
		// vo.setProcessInstanceId(processInstance.getId());
		// vo.setProcessDefinitionId(processInstance.getProcessDefinitionId());
		// vo.setProcessDefinitionKey(processInstance.getProcessDefinitionKey());
		// vo.setProcessDefinitionName(processInstance.getProcessDefinitionName());
		// vo.setProcessDefinitionVersion(processInstance.getProcessDefinitionVersion());
		// vo.setDeploymentId(processInstance.getDeploymentId());
		// vo.setStartTime(processInstance.getStartTime());
		// vo.setEndTime(processInstance.getEndTime());
		// vo.setDurationInMillis(processInstance.getDurationInMillis());
		// vo.setDeleteReason(processInstance.getDeleteReason());
	}

	public static void madeVariableVo(HistoricVariableInstance hivv,
			VariableVo vo) {
		if (vo == null || "".equals(vo)) {
			vo = new VariableVo();
		}
		HistoricVariableInstanceEntity hvie = (HistoricVariableInstanceEntity) hivv;
		vo.setName(hvie.getName());
		vo.setCachedValue(hvie.getCachedValue());
		vo.setExecutionId(hvie.getExecutionId());
		vo.setDoubleValue(hvie.getDoubleValue());
		// vo.setVariableType(hvie.getVariableType());
		vo.setProcessInstanceId(hvie.getProcessInstanceId());
		vo.setLastUpdatedTime(hvie.getLastUpdatedTime());
		// vo.setTypeName(hvie.getTypeName());
		// vo.setType(hvie.getType());
		vo.setId(hvie.getId());
		vo.setTaskId(hvie.getTaskId());
		vo.setTextValue(hvie.getTextValue());
		vo.setTextValue2(hvie.getTextValue2());
		vo.setCreateTime(hvie.getCreateTime());
		vo.setRevision(hvie.getRevision());
		// vo.setDeleted(hvie.getDeleted());
		vo.setLongValue(hvie.getLongValue());
		// vo.setLocalizedDescription(hvie.getLocalizedDescription());
		// vo.setLocalizedName(hvie.getLocalizedName());
		// vo.setForcedUpdate(hvie.getForcedUpdate());
	}

	public static void madeProcessDefinitionVo(
			ProcessDefinition processDefinition, ProcessDefinitionVo vo) {

		if (vo == null || "".equals(vo)) {
			vo = new ProcessDefinitionVo();
		}

		vo.setVersion(processDefinition.getVersion());
		vo.setKey(processDefinition.getKey());
		vo.setCategory(processDefinition.getCategory());
		vo.setDeploymentId(processDefinition.getDeploymentId());
		vo.setResourceName(processDefinition.getResourceName());
		vo.setTenantId(processDefinition.getTenantId());
		vo.setDiagramResourceName(processDefinition.getDiagramResourceName());
		vo.setGraphicalNotationDefined(processDefinition.hasGraphicalNotation());
		vo.setHasStartFormKey(processDefinition.hasStartFormKey());
		vo.setName(processDefinition.getName());
		vo.setDescription(processDefinition.getDescription());
		vo.setId(processDefinition.getId());
	}
}
