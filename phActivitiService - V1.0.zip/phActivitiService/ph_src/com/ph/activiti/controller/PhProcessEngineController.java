package com.ph.activiti.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ph.activiti.service.PhProcessService;
import com.ph.activiti.utils.Page;
import com.ph.activiti.vo.ProcessDefinitionVo;
import com.ph.activiti.vo.ProcessInstanceVo;
import com.ph.activiti.vo.TaskVo;

@Controller
@RequestMapping("/mvc/phProcess")
public class PhProcessEngineController {

	private static Logger logger = Logger.getLogger(PhProcessEngineController.class);
	
	@Resource
	private PhProcessService phProcessService;

	/**
	 * 查询所有流程定义列表
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping("/queryAllProcessDefinition.do")
	public void queryAllProcessDefinition(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始查询所有流程定义列表！");
		response.setContentType("text/html;charset=utf-8");
		
		List<ProcessDefinitionVo> list = phProcessService//
				.queryAllProcessDefinition();
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(list);

		response.getWriter().print(json);

	}
	/**
	 * 分页获取流程实例，根据启动这个流程的用户获取
	 * @param startUser ： 启动流程的用户ID
	 * @param pageNum ： 待查询的页码
	 * @param row ： 每页显示数据条数
	 * @return
	 */
	@RequestMapping("/queryProcessInstancesListPageByStartUser.do")
	public void queryProcessInstancesListPageByStartUser(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始查询流程实例列表，根据启动这个流程的用户获取！");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String startUser = request.getParameter("startUser");
		String pn = request.getParameter("pageNum");
		String rowStr = request.getParameter("row");
		
		int row = 10;
		int pageNum = 1;
		
		if(pn != null && !"".equals(pn)){
			try {
				pageNum = Integer.parseInt(pn);
			} catch (Exception e) {}
		}
		if(rowStr != null && !"".equals(rowStr)){
			try {
				row = Integer.parseInt(rowStr);
			} catch (Exception e) {}
		}
		
		Page<ProcessInstanceVo> page = phProcessService//
				.queryProcessInstancesListPageByStartUser(startUser,pageNum,row);
		
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(page);

		response.getWriter().print(json);

	}
	/**
	 * 获取流程的所有活动【这里只获取任务】节点的的执行情况
	 * 就相当于获取流程的审批进度
	 * @param processInstanceId
	 *            ：流程实例ID
	 * @return
	 */
	@RequestMapping("/queryInstanceDetail.do")
	public void queryInstanceDetail(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始查询流程的审批进度，根据流程实例ID！");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String processInstanceId = request.getParameter("processInstanceId");
		
		List<TaskVo> list = phProcessService//
				.queryInstanceDetail(processInstanceId);
		
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(list);
		
		response.getWriter().print(json);
		
	}
	/**
	 * 获取某流程实例目前正在执行的任务
	 * 就相当于获取流程的审批进度
	 * @param processInstanceId
	 *            ：流程实例ID
	 * @return
	 */
	@RequestMapping("/queryInstanceCurrentDoingTask.do")
	public void queryInstanceCurrentDoingTask(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始查询流程实例目前正在执行的任务，根据流程实例ID！");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String processInstanceId = request.getParameter("processInstanceId");
		
		List<TaskVo> list = phProcessService//
						.queryInstanceCurrentDoingTask(processInstanceId);
		
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(list);
		
		response.getWriter().print(json);
		
	}
	
	/**
	 * 根据用户查询当前正在执行的任务列表
	 * <br>待办任务
	 * @param assignee ：用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/queryTaskListByAssignee.do")
	public void queryTaskListByAssignee(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始查询用户的待办任务列表，根据用户ID！");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String assignee = request.getParameter("assignee");
		String pn = request.getParameter("pageNum");
		String rowStr = request.getParameter("row");
		
		int row = 10;
		int pageNum = 1;
		
		if(pn != null && !"".equals(pn)){
			try {
				pageNum = Integer.parseInt(pn);
			} catch (Exception e) {}
		}
		if(rowStr != null && !"".equals(rowStr)){
			try {
				row = Integer.parseInt(rowStr);
			} catch (Exception e) {}
		}
		
		Page<TaskVo> page = phProcessService.queryTaskListByAssignee(assignee, pageNum, row);
		
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(page);

		response.getWriter().print(json);
		
	}
	/**
	 * 分页查询用户的已办信息，也就是用户处理过的任务
	 * <br>待办任务
	 * @param assignee ：用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/queryHisTaskListByAssignee.do")
	public void queryHisTaskListByAssignee(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始查询用户已经处理过的任务列表，根据用户ID！");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String assignee = request.getParameter("assignee");
		String pn = request.getParameter("pageNum");
		String rowStr = request.getParameter("row");
		
		int row = 10;
		int pageNum = 1;
		
		if(pn != null && !"".equals(pn)){
			try {
				pageNum = Integer.parseInt(pn);
			} catch (Exception e) {}
		}
		if(rowStr != null && !"".equals(rowStr)){
			try {
				row = Integer.parseInt(rowStr);
			} catch (Exception e) {}
		}
		
		Page<TaskVo> page = phProcessService.queryHisTaskListByAssignee(assignee, pageNum, row);
		
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(page);
		
		response.getWriter().print(json);
		
	}
	/**
	 * 启动流程，使用key值启动，默认就是按照最新版本的流程定义进行启动
	 * @param key ：流程的key
	 * @param startUser ： 启动流程的用户ID
	 * @param variables：流程变量
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/startProcess.do")
	public void startProcess(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始启动流程，根据流程KEY！");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String key = request.getParameter("key");
		String startUser = request.getParameter("startUser");
		String vs = request.getParameter("variables");
		ObjectMapper mapper = new ObjectMapper();
		
		//JavaType javaType = mapper.getTypeFactory().constructParametricType(new HashMap<String,Object>().getClass(),String.class);
		@SuppressWarnings("unchecked")
		Map<String,Object> variables = mapper.readValue(vs, HashMap.class);
		
		ProcessInstanceVo instanceVo = phProcessService.startProcess(key, startUser, variables);
		
		String json = mapper.writeValueAsString(instanceVo);
		
		response.getWriter().print(json);
		
	}
	
	
	/**
	 * 执行任务
	 * @param taskId ：任务ID
	 * @param doTaskType：执行任务的类型， 1：同意   ；0：拒绝
	 * @param variables：流程变量
	 * @param varIsBindTaskId ： 流程变量是否绑定当前任务，默认为不绑定
	 * @throws Exception
	 */
	@RequestMapping("/doTask.do")
	public void doTask(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始执行任务，根据任务ID！");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		try {
			String taskId = request.getParameter("taskId");
			String dt = request.getParameter("doTaskType");
			String vbt = request.getParameter("varIsBindTaskId");
			String vs = request.getParameter("variables");
			ObjectMapper mapper = new ObjectMapper();
			
//			JavaType javaType = mapper.getTypeFactory().constructParametricType(HashMap.class,String.class);
			@SuppressWarnings("unchecked")
			Map<String,Object> variables = mapper.readValue(vs, HashMap.class);
			
			int doTaskType = 1;
			boolean varIsBindTaskId = false;
			
			if(dt != null && !"".equals(dt)){
				try {
					doTaskType = Integer.parseInt(dt);
				} catch (Exception e) {}
			}
			if("1".equals(vbt)){
				varIsBindTaskId = true;
			}
			phProcessService.doTask(taskId, doTaskType, variables, varIsBindTaskId);
			response.getWriter().print("{\"isSucceed\":\"1\"}");
		} catch (Exception e) {
			response.getWriter().print("{\"isSucceed\":\"0\",\"msg\":\""+e.getMessage()+"\"}");
			throw e;
		}
				
		
	}
	
	/**
	 * 设置流程变量
	 * @param taskId ：任务ID
	 * @param doTaskType：执行任务的类型， 1：同意   ；0：拒绝
	 * @param variables：流程变量
	 * @param varIsBindTaskId ： 流程变量是否绑定当前任务，默认为不绑定
	 * @throws Exception
	 */
	@RequestMapping("/setVariables.do")
	public void setVariables(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		logger.info("Activiti服务端：开始 设置流程变量！");
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		try {
			String taskId = request.getParameter("taskId");
			String vbt = request.getParameter("varIsBindTaskId");
			String vs = request.getParameter("variables");
			ObjectMapper mapper = new ObjectMapper();
			
//			JavaType javaType = mapper.getTypeFactory().constructParametricType(HashMap.class,String.class);
			@SuppressWarnings("unchecked")
			Map<String,Object> variables = mapper.readValue(vs, HashMap.class);
			
			boolean varIsBindTaskId = false;
			
			if("1".equals(vbt)){
				varIsBindTaskId = true;
			}
			phProcessService.setVariables(taskId, variables, varIsBindTaskId);
			response.getWriter().print("{\"isSucceed\":\"1\"}");
		} catch (Exception e) {
			response.getWriter().print("{\"isSucceed\":\"0\",\"msg\":\""+e.getMessage()+"\"}");
			throw e;
		}
		
		
	}
	
	

}
