package com.ph.activiti.service;

import java.util.List;
import java.util.Map;

import com.ph.activiti.utils.Page;
import com.ph.activiti.vo.ProcessDefinitionVo;
import com.ph.activiti.vo.ProcessInstanceVo;
import com.ph.activiti.vo.TaskVo;

public interface PhProcessService {

	
	/**
	 * 查询所有流程定义列表
	 * <br>查询已经部署好了的流程，如果一个流程有多个版本，默认查询最新的那个版本。
	 * @return
	 * @throws Exception
	 */
	List<ProcessDefinitionVo> queryAllProcessDefinition() throws Exception;
	/**
	 * 分页获取流程实例，根据启动这个流程的用户获取
	 * @param startUser ： 启动流程的用户ID
	 * @param pageNum ： 待查询的页码
	 * @param row ： 每页显示数据条数
	 * @return
	 */
	Page<ProcessInstanceVo> queryProcessInstancesListPageByStartUser(String startUser,int pageNum,int row) throws Exception;
	
	/**
	 * 获取流程的所有活动【这里只获取任务】节点的的执行情况
	 * 就相当于获取流程的审批进度
	 * @param processInstanceId ：流程实例ID
	 */
	List<TaskVo> queryInstanceDetail(String processInstanceId) throws Exception;
	
	/**
	 * 获取某流程实例目前正在执行的任务
	 * 就相当于获取流程的审批进度
	 * @param processInstanceId ：流程实例ID
	 */
	List<TaskVo> queryInstanceCurrentDoingTask(String processInstanceId) throws Exception;
	
	/**
	 * 根据用户查询当前正在执行的任务列表
	 * <br>待办任务
	 * @param assignee ：用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 * @throws Exception
	 */
	Page<TaskVo> queryTaskListByAssignee(String assignee, int pageNum, int row) throws Exception;
	
	
	
	
	/**
	 * 分页查询用户的已办信息，也就是用户处理过的任务
	 * <br>待办任务
	 * @param assignee ：用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 * @throws Exception
	 */
	Page<TaskVo> queryHisTaskListByAssignee(String assignee, int pageNum, int row) throws Exception;
	
	
	/**
	 * 启动流程，使用key值启动，默认就是按照最新版本的流程定义进行启动
	 * @param key ：流程的key
	 * @param startUser ： 启动流程的用户ID
	 * @param variables：流程变量
	 * @return
	 * @throws Exception
	 */
	ProcessInstanceVo startProcess(String key,String startUser,Map<String,Object> variables) throws Exception;
	

	/**
	 * 执行任务
	 * @param taskId ：任务ID
	 * @param doTaskType：执行任务的类型， 1：同意   ；0：拒绝
	 * @param variables：流程变量
	 * @param varIsBindTaskId ： 流程变量是否绑定当前任务，默认为不绑定
	 * @throws Exception
	 */
	void doTask(String taskId,int doTaskType,Map<String,Object> variables,boolean varIsBindTaskId) throws Exception;
	/**
	 * 设置流程变量
	 * @param taskId ：任务ID
	 * @param variables：流程变量
	 * @param varIsBindTaskId ： 流程变量是否绑定当前任务，默认为不绑定
	 * @throws Exception
	 */
	void setVariables(String taskId, Map<String, Object> variables,
			boolean varIsBindTaskId) throws Exception;
	

}
