package com.ph.activiti.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.ph.activiti.service.PhProcessService;
import com.ph.activiti.utils.MyBeanUtils;
import com.ph.activiti.utils.Page;
import com.ph.activiti.vo.ProcessDefinitionVo;
import com.ph.activiti.vo.ProcessInstanceVo;
import com.ph.activiti.vo.TaskVo;
import com.ph.activiti.vo.VariableVo;

@Service("phProcessService")
public class PhProcessServiceImpl implements PhProcessService {

	private static Logger logger = Logger.getLogger(PhProcessServiceImpl.class);

	/**
	 * 管理流程定义
	 */
	@Resource
	private RepositoryService repositoryService;
	/**
	 * 执行管理，包括：启动、推进、删除流程实例等操作；
	 */
	@Resource
	private RuntimeService runtimeService;
	/**
	 * 任务管理
	 */
	@Resource
	private TaskService taskService;
	/**
	 * 历史管理(执行完的数据的管理)
	 */
	@Resource
	private HistoryService historyService;

	@Resource
	private IdentityService identityService;
	
	
	
	/**
	 * 查询所有流程定义列表
	 * <br>查询已经部署好了的流程，如果一个流程有多个版本，默认查询最新的那个版本。
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ProcessDefinitionVo> queryAllProcessDefinition()
			throws Exception {
		List<ProcessDefinitionVo> list;
		try {
			List<ProcessDefinition> temp = repositoryService
					.createProcessDefinitionQuery()//
					.orderByProcessDefinitionId().asc()// 按照版本的升序排列
					.list();// 总的结果集数量，封装流程定义
			list = this.proDefinFilter(temp);

			logger.info("查询所有流程定义列表：" + list.size() + " 条信息！");

		} catch (Exception e) {
			logger.error("查询所有流程定义列表失败，错误信息：" + e.getMessage());
			throw e;
		}
		return list;
	}


	/**
	 * 分页获取流程实例，根据启动这个流程的用户获取
	 * 
	 * @param startUser
	 *            ： 启动流程的用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 */
	@Override
	public Page<ProcessInstanceVo> queryProcessInstancesListPageByStartUser(
			String startUser, int pageNum, int row) throws Exception {
		try {
			if (startUser != null && !"".equals(startUser)) {

				// Long count =
				// runtimeService.createProcessInstanceQuery().involvedUser(startUser).count();
				Long count = historyService
						.createHistoricProcessInstanceQuery()//
						.startedBy(startUser)//
						.count();

				int allRow = count.intValue();

				Page<ProcessInstanceVo> page = new Page<ProcessInstanceVo>(
						pageNum, row, allRow);

				int firstResult = page.getStartIndex();// 起始下标
				int maxResults = page.getRows();// 每页显示条数

				List<HistoricProcessInstance> list = historyService
						.createHistoricProcessInstanceQuery()//
						.startedBy(startUser)//
						.listPage(firstResult, maxResults);

				List<ProcessInstanceVo> voList = new ArrayList<>();
				if (list != null && list.size() > 0) {
					for (HistoricProcessInstance hpi : list) {
						ProcessInstanceVo vo = new ProcessInstanceVo();
						MyBeanUtils.madeProcessInstanceVo(hpi, vo);
						
						//流程变量
						List<HistoricVariableInstance> list2 = historyService.createHistoricVariableInstanceQuery()//
								.processInstanceId(hpi.getId()).list(); 
						
						if(list2 != null && list2.size()>0){
							
							List<VariableVo> queryVariables = new ArrayList<>();
							for(HistoricVariableInstance hi : list2){
								VariableVo vvo = new VariableVo();
								MyBeanUtils.madeVariableVo(hi, vvo);
								queryVariables.add(vvo);
							}
							vo.setQueryVariables(queryVariables);
						}
						
						voList.add(vo);
					}
				}
				page.setList(voList);

				// List<ProcessInstance> list =
				// runtimeService.createProcessInstanceQuery()//
				// .involvedUser(startUser)//
				// .listPage(firstResult, maxResults);
				// page.setList(list);
				logger.info("查询当前用户的流程实例列表：" + list.size() + " 条信息！");
				return page;
			} else {
				String msg = "需要的参数”启动流程的用户ID“为 NULL ，查询用户当前用户的流程实例列表失败！";
				logger.warn(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error("查询当前用户的流程实例列表失败，错误信息：" + e.getMessage());
			throw e;
		}

	}

	/**
	 * 获取流程的所有活动【这里只获取任务】节点的的执行情况 就相当于获取流程的审批进度
	 * 
	 * @param processInstanceId
	 *            ：流程实例ID
	 */
	@Override
	public List<TaskVo> queryInstanceDetail(String processInstanceId) throws Exception  {
		
		try {
			if (processInstanceId != null && !"".equals(processInstanceId)) {

				List<HistoricTaskInstance> list = historyService
						.createHistoricTaskInstanceQuery()//
						.processInstanceId(processInstanceId).list();

				List<HistoricVariableInstance> list2 = historyService
						.createHistoricVariableInstanceQuery()//
						.processInstanceId(processInstanceId).list();

				List<TaskVo> taskVos = new ArrayList<TaskVo>();
				if (list != null && list.size() > 0) {
					for (HistoricTaskInstance i : list) {

						TaskVo tVo = new TaskVo();
						MyBeanUtils.madeTaskVo(i, tVo);

						List<VariableVo> queryVariables = new ArrayList<>();

						String taskId = i.getId();
						if (list2 != null && list2.size() > 0) {

							for (HistoricVariableInstance hi : list2) {
								String tempTaskId = hi.getTaskId();
								if (taskId.equals(tempTaskId)) {
									VariableVo vvo = new VariableVo();
									MyBeanUtils.madeVariableVo(hi, vvo);
									queryVariables.add(vvo);
								}
							}
							// 添加流程变量
							tVo.setQueryVariables(queryVariables);
						}
						taskVos.add(tVo);
					}
				}
				
				logger.info("查询当前用户的流程实例列表：" + taskVos.size() + " 条信息！");
				return taskVos;
			} else {
				String msg = "需要的参数”流程实例ID“为 NULL ，查询流程的审批进度列表失败！";
				logger.warn(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error("查询流程的审批进度列表失败，错误信息：" + e.getMessage());
			throw e;
		}
		
	}
	/**
	 * 获取某流程实例目前正在执行的任务
	 * 就相当于获取流程的审批进度
	 * @param processInstanceId ：流程实例ID
	 */
	@Override
	public List<TaskVo> queryInstanceCurrentDoingTask(String processInstanceId) throws Exception  {
		
		try {
			if (processInstanceId != null && !"".equals(processInstanceId)) {
				
				List<Task> list = taskService.createTaskQuery()//
							.processInstanceId(processInstanceId)//
							.orderByTaskCreateTime().desc()//
							.list();
				
				
				List<TaskVo> taskVos = new ArrayList<TaskVo>();
				if (list != null && list.size() > 0) {
					for (Task i : list) {
						
						TaskVo tVo = new TaskVo();
						MyBeanUtils.madeTaskVo(i, tVo);
						
						taskVos.add(tVo);
					}
				}
				
				logger.info("查询流程实例目前正在执行的任务列表：" + taskVos.size() + " 条信息！");
				return taskVos;
			} else {
				String msg = "需要的参数”流程实例ID“为 NULL ，查询流程实例目前正在执行的任务失败！";
				logger.warn(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error("查询流程实例目前正在执行的任务失败，错误信息：" + e.getMessage());
			throw e;
		}
		
	}


	/**
	 * 根据用户查询当前正在执行的任务列表
	 * <br>待办任务
	 * @param assignee ：用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 * @throws Exception
	 */
	@Override
	public Page<TaskVo> queryTaskListByAssignee(String assignee, int pageNum, int row)
			throws Exception {
		
		try {
			if (assignee != null && !"".equals(assignee)) {

				Long count = taskService.createTaskQuery()//
						.taskAssignee(assignee)//
						.count();

				int allRow = count.intValue();

				Page<TaskVo> page = new Page<TaskVo>(
						pageNum, row, allRow);

				int firstResult = page.getStartIndex();// 起始下标
				int maxResults = page.getRows();// 每页显示条数

				List<Task> list = taskService.createTaskQuery()//
						.taskAssignee(assignee)//
						.orderByTaskCreateTime().desc()//
						.listPage(firstResult, maxResults);


				List<TaskVo> taskVos = new ArrayList<TaskVo>();
				if (list != null && list.size() > 0) {
					for(Task task : list){
						TaskVo tVo = new TaskVo();
						MyBeanUtils.madeTaskVo(task, tVo);
						
						//流程变量
						Map<String, Object> variables = taskService.getVariables(task.getId());
						
						if(!variables.isEmpty()){
							List<VariableVo> queryVariables = new ArrayList<>();
							
							Set<String> keySet = variables.keySet();
							Iterator<String> it = keySet.iterator();
							while(it.hasNext()){
								String key = it.next();
								Object value = variables.get(key);
								
								VariableVo vvo = new VariableVo();
								
								vvo.setTaskId(task.getId());
								vvo.setName(key);
								vvo.setTextValue(value+"");
								queryVariables.add(vvo);
							}
							tVo.setQueryVariables(queryVariables);
						}
						taskVos.add(tVo);
					}
					page.setList(taskVos);
				}
				logger.info("查询用户当前的待办任务列表：" + taskVos.size() + " 条信息！");
				return page;
			} else {
				String msg = "需要的参数”获取待办列表的用户ID“为 NULL ，查询用户当前的待办任务列表失败！";
				logger.warn(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error("查询用户当前的待办任务列表失败，错误信息：" + e.getMessage());
			throw e;
		}

	}
	
	
	/**
	 * 分页查询用户的已办信息，也就是用户处理过的任务
	 * <br>待办任务
	 * @param assignee ：用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 * @throws Exception
	 */
	@Override
	public Page<TaskVo> queryHisTaskListByAssignee(String assignee, int pageNum, int row) throws Exception{
		try {
			if (assignee != null && !"".equals(assignee)) {

				Long count = historyService.createHistoricTaskInstanceQuery()//
						.taskAssignee(assignee)//
						.count();

				int allRow = count.intValue();

				Page<TaskVo> page = new Page<TaskVo>(
						pageNum, row, allRow);

				int firstResult = page.getStartIndex();// 起始下标
				int maxResults = page.getRows();// 每页显示条数

				List<HistoricTaskInstance> list = historyService.createHistoricTaskInstanceQuery()//
						.taskAssignee(assignee)//
						.finished()//已经结束了的
						.orderByHistoricTaskInstanceEndTime().desc()//
						.listPage(firstResult, maxResults);


				List<TaskVo> taskVos = new ArrayList<TaskVo>();
				if (list != null && list.size() > 0) {
					for(HistoricTaskInstance task : list){
						TaskVo tVo = new TaskVo();
						MyBeanUtils.madeTaskVo(task, tVo);
						
						//流程变量
						List<HistoricVariableInstance> variables = historyService.createHistoricVariableInstanceQuery()//
							.taskId(task.getId())
							.list();
						List<VariableVo> queryVariables = new ArrayList<>();
						if(variables != null && variables.size()>0){
							for(HistoricVariableInstance v : variables){
								VariableVo vo = new VariableVo();
								MyBeanUtils.madeVariableVo(v, vo );
								queryVariables.add(vo);
							}
						}
						tVo.setQueryVariables(queryVariables );
						taskVos.add(tVo);
					}
					page.setList(taskVos);
				}
				logger.info("查询用户历史任务列表：" + taskVos.size() + " 条信息！");
				return page;
			} else {
				String msg = "需要的参数”获取历史任务的用户ID“为 NULL ，查询用户历史任务列表失败！";
				logger.warn(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error("查询用户历史任务列表失败，错误信息：" + e.getMessage());
			throw e;
		}
	}
	

	/**
	 * 启动流程，使用key值启动，默认就是按照最新版本的流程定义进行启动
	 * @param key ：流程的key
	 * @param startUser ： 启动流程的用户ID
	 * @param variables：流程变量
	 * @return
	 * @throws Exception
	 */
	@Override
	public ProcessInstanceVo startProcess(String key, String startUser,
			Map<String, Object> variables) throws Exception {
		
		try {
			if ((startUser != null && !"".equals(startUser)) && 
					(key != null && !"".equals(key))) {
				
				variables.put("startUser", startUser);
				identityService.setAuthenticatedUserId(startUser);
				ProcessInstance instance = runtimeService.startProcessInstanceByKey(key,variables);
				
				ProcessInstanceVo vo = new ProcessInstanceVo();
				MyBeanUtils.madeProcessInstanceVo(instance, vo );
				
				logger.info("用户【"+startUser+"】启动流程【"+key+"】的实例成功，实例ID ：" + instance.getId());
				return vo;
			} else {
				String msg = "";
				if(key == null || "".equals(key)){
					msg = "需要的参数”流程的 key“为 NULL ，用户【"+startUser+"】启动流程【"+key+"】失败！";
				}else{
					msg = "需要的参数”启动流程的用户ID“为 NULL ，用户【"+startUser+"】启动流程【"+key+"】失败！";
				}
				logger.warn(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error("用户【"+startUser+"】启动流程【"+key+"】失败，错误信息：" + e.getMessage());
			throw e;
		}
	}
	
	
	/**
	 * 执行任务
	 * @param taskId ：任务ID
	 * @param doTaskType：执行任务的类型， 1：同意   ；0：拒绝
	 * @param variables：流程变量
	 * @param varIsBindTaskId ： 流程变量是否绑定当前任务，默认为不绑定
	 * @throws Exception
	 */
	@Override
	public void doTask(String taskId,int doTaskType, Map<String, Object> variables,
			boolean varIsBindTaskId) throws Exception {
		try {
			if ((taskId != null && !"".equals(taskId))) {
				
				Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
				if(!(doTaskType == 1 || doTaskType == 0)){
					doTaskType = 1;
				}
				taskService.setVariableLocal(taskId, "agree", doTaskType+"");
				runtimeService.setVariable(task.getExecutionId(), "agree", ""+doTaskType);
				
				if(varIsBindTaskId){
					taskService.setVariablesLocal(taskId, variables);
				}else{
					taskService.setVariables(taskId, variables);
				}
				
				taskService.complete(task.getId());
				
				logger.info("执行任务【"+task.getName()+"】成功！");
			} else {
				String msg = "需要的参数”待执行的任务ID“为 NULL ，执行任务失败！";
				logger.warn(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error("执行任务【"+taskId+"】失败，错误信息：" + e.getMessage());
			throw e;
		}
	}
	/**
	 * 设置流程变量
	 * @param taskId ：任务ID
	 * @param variables：流程变量
	 * @param varIsBindTaskId ： 流程变量是否绑定当前任务，默认为不绑定
	 * @throws Exception
	 */
	@Override
	public void setVariables(String taskId, Map<String, Object> variables,
			boolean varIsBindTaskId) throws Exception {
		try {
			
			if ((taskId != null && !"".equals(taskId))) {
				
				if(varIsBindTaskId){
					taskService.setVariablesLocal(taskId, variables);
				}else{
					taskService.setVariables(taskId, variables);
				}
				logger.info("设置流程变量成功！");
			} else {
				String msg = "需要的参数”任务ID“为 NULL ，设置流程变量失败！";
				logger.warn(msg);
				throw new Exception(msg);
			}
		} catch (Exception e) {
			logger.error("设置流程变量失败，错误信息：" + e.getMessage());
			throw e;
		}
	}

	/**
	 * 流程定义列表数据过滤：将有多个版本的流程定义，剔除老版本，只留最新的版本
	 * 
	 * @param oldList
	 * @return
	 */
	private List<ProcessDefinitionVo> proDefinFilter(
			List<ProcessDefinition> oldList) {

		if (oldList != null && oldList.size() > 0) {
			Map<String, ProcessDefinition> map = new HashMap<>();

			for (ProcessDefinition pd : oldList) {
				map.put(pd.getKey(), pd);
			}
			Set<String> keySet = map.keySet();
			List<ProcessDefinitionVo> newList = new ArrayList<ProcessDefinitionVo>();
			if (!keySet.isEmpty()) {
				Iterator<String> it = keySet.iterator();
				while (it.hasNext()) {
					String key = it.next();
					ProcessDefinition temp = map.get(key);
					ProcessDefinitionVo vo = new ProcessDefinitionVo();
					MyBeanUtils.madeProcessDefinitionVo(temp, vo);
					newList.add(vo);
				}
			}
			return newList;
		}
		return new ArrayList<ProcessDefinitionVo>();

	}

}
