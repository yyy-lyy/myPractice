package com.ph.activiti.vo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TransitionVo {

	protected ActivityVo source;
	protected ActivityVo destination;
	// protected List<ExecutionListener> executionListeners;
	// protected Expression skipExpression;
	/** Graphical information: a list of waypoints: x1, y1, x2, y2, x3, y3, .. */
	protected List<Integer> waypoints = new ArrayList<Integer>();

	public ActivityVo getSource() {
		return source;
	}

	public void setSource(ActivityVo source) {
		this.source = source;
	}

	public ActivityVo getDestination() {
		return destination;
	}

	public void setDestination(ActivityVo destination) {
		this.destination = destination;
	}

	public List<Integer> getWaypoints() {
		return waypoints;
	}

	public void setWaypoints(List<Integer> waypoints) {
		this.waypoints = waypoints;
	}

}
