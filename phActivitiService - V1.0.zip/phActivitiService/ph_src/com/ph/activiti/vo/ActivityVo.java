package com.ph.activiti.vo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ActivityVo {

	  private List<TransitionVo> outgoingTransitions = new ArrayList<TransitionVo>();
	  private Map<String, TransitionVo> namedOutgoingTransitions = new HashMap<String, TransitionVo>();
	  private Map<String, Object> variables;
	  private List<TransitionVo> incomingTransitions = new ArrayList<TransitionVo>();
//	  private ActivityBehavior activityBehavior;
	  private ActivityVo parent;
	  private boolean isScope;
	  private boolean isAsync;
	  private boolean isExclusive;
	  private String failedJobRetryTimeCycleValue;
	  
	  // Graphical information
	  private int x = -1;
	  private int y = -1;
	  private int width = -1;
	  private int height = -1;
	  
	  private List<ActivityVo> activities = new ArrayList<ActivityVo>();
	  private Map<String, ActivityVo> namedActivities = new HashMap<String, ActivityVo>();
//	  private Map<String, List<ExecutionListener>> executionListeners = new HashMap<String, List<ExecutionListener>>();
//	  private IOSpecification ioSpecification;
	  
	  private String id;
	  private ProcessDefinitionVo processDefinition;
//	  private Map<String, Object> properties;
	public List<TransitionVo> getOutgoingTransitions() {
		return outgoingTransitions;
	}
	public void setOutgoingTransitions(List<TransitionVo> outgoingTransitions) {
		this.outgoingTransitions = outgoingTransitions;
	}
	public Map<String, TransitionVo> getNamedOutgoingTransitions() {
		return namedOutgoingTransitions;
	}
	public void setNamedOutgoingTransitions(
			Map<String, TransitionVo> namedOutgoingTransitions) {
		this.namedOutgoingTransitions = namedOutgoingTransitions;
	}
	public Map<String, Object> getVariables() {
		return variables;
	}
	public void setVariables(Map<String, Object> variables) {
		this.variables = variables;
	}
	public List<TransitionVo> getIncomingTransitions() {
		return incomingTransitions;
	}
	public void setIncomingTransitions(List<TransitionVo> incomingTransitions) {
		this.incomingTransitions = incomingTransitions;
	}
	public ActivityVo getParent() {
		return parent;
	}
	public void setParent(ActivityVo parent) {
		this.parent = parent;
	}
	public boolean isScope() {
		return isScope;
	}
	public void setScope(boolean isScope) {
		this.isScope = isScope;
	}
	public boolean isAsync() {
		return isAsync;
	}
	public void setAsync(boolean isAsync) {
		this.isAsync = isAsync;
	}
	public boolean isExclusive() {
		return isExclusive;
	}
	public void setExclusive(boolean isExclusive) {
		this.isExclusive = isExclusive;
	}
	public String getFailedJobRetryTimeCycleValue() {
		return failedJobRetryTimeCycleValue;
	}
	public void setFailedJobRetryTimeCycleValue(String failedJobRetryTimeCycleValue) {
		this.failedJobRetryTimeCycleValue = failedJobRetryTimeCycleValue;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public List<ActivityVo> getActivities() {
		return activities;
	}
	public void setActivities(List<ActivityVo> activities) {
		this.activities = activities;
	}
	public Map<String, ActivityVo> getNamedActivities() {
		return namedActivities;
	}
	public void setNamedActivities(Map<String, ActivityVo> namedActivities) {
		this.namedActivities = namedActivities;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ProcessDefinitionVo getProcessDefinition() {
		return processDefinition;
	}
	public void setProcessDefinition(ProcessDefinitionVo processDefinition) {
		this.processDefinition = processDefinition;
	}
//	public Map<String, Object> getProperties() {
//		return properties;
//	}
//	public void setProperties(Map<String, Object> properties) {
//		this.properties = properties;
//	}
	  
	  
	  
}
