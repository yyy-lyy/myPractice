package com.ph.activiti.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class StartingExecution {
	 
	  protected final ActivityVo selectedInitial;

	  public StartingExecution(ActivityVo selectedInitial) {
	    this.selectedInitial = selectedInitial;
	  }

	  public ActivityVo getInitial() {
	    return selectedInitial;
	  }
	  
}
