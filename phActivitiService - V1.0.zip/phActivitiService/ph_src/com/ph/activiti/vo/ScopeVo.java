package com.ph.activiti.vo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class ScopeVo {

	
	  private List<ActivityVo> activities = new ArrayList<ActivityVo>();
	  private Map<String, ActivityVo> namedActivities = new HashMap<String, ActivityVo>();
//	  private Map<String, List<ExecutionListener>> executionListeners = new HashMap<String, List<ExecutionListener>>();
//	  private IOSpecification ioSpecification;
	  private String id;
	  public List<ActivityVo> getActivities() {
		return activities;
	}
	public void setActivities(List<ActivityVo> activities) {
		this.activities = activities;
	}
	public Map<String, ActivityVo> getNamedActivities() {
		return namedActivities;
	}
	public void setNamedActivities(Map<String, ActivityVo> namedActivities) {
		this.namedActivities = namedActivities;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ProcessDefinitionVo getProcessDefinition() {
		return processDefinition;
	}
	public void setProcessDefinition(ProcessDefinitionVo processDefinition) {
		this.processDefinition = processDefinition;
	}
	public Map<String, Object> getProperties() {
		return properties;
	}
	public void setProperties(Map<String, Object> properties) {
		this.properties = properties;
	}
	private ProcessDefinitionVo processDefinition;
	  private Map<String, Object> properties;
}
