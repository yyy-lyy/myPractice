package com.ph.activiti.client.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.ph.activiti.client.service.PhActivitiService;
import com.ph.activiti.client.utils.HttpClientUtil;
import com.ph.activiti.client.utils.Page;
import com.ph.activiti.client.utils.Utils;
import com.ph.activiti.client.vo.ProcessDefinitionVo;
import com.ph.activiti.client.vo.ProcessInstanceVo;
import com.ph.activiti.client.vo.TaskVo;

/**
 * Activiti 流程引擎 Service，提供部分Activiti核心服务
 * @author yangyunyun<br>
 * 2017年3月24日
 */
@Service("phActivitiService")
public class PhActivitiServiceImpl implements PhActivitiService {

	private static Logger logger = Logger.getLogger(PhActivitiServiceImpl.class);
	
	/**
	 * 查询所有流程定义列表
	 * <br>查询已经部署好了的流程，如果一个流程有多个版本，默认查询最新的那个版本。
	 * @return
	 * @throws Exception
	 */
	@Override
	public List<ProcessDefinitionVo> queryAllProcessDefinition()
			throws Exception {

		String url = Utils.queryAllProcessDefinitionUrl;
		logger.info("开始远程查询所有流程定义列表，远程服务地址："+url);
		
		String resultStr = HttpClientUtil.httpConnect(url, null);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		List<ProcessDefinitionVo> list = new ArrayList<ProcessDefinitionVo>();
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			list = Utils.json2Bean(data,list,new ProcessDefinitionVo());
			
			logger.info("结束远程查询所有流程定义列表："+list.size()+" 条信息！");
		}else{
			logger.error("远程查询所有流程定义列表失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
		return list;
	}
	
	/**
	 * 分页获取流程实例，根据启动这个流程的用户获取
	 * @param startUser ： 启动流程的用户ID
	 * @param pageNum ： 待查询的页码
	 * @param row ： 每页显示数据条数
	 * @return
	 */
	@Override
	public Page<ProcessInstanceVo> queryProcessInstancesListPageByStartUser(String startUser,int pageNum,int row)
			throws Exception {
		
		String url = Utils.queryProcessInstancesListPageByStartUser;
		logger.info("开始远程分页查询用户【"+startUser+"】启动的流程实例列表，远程服务地址："+url);
		
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("startUser", startUser));
		params.add(new BasicNameValuePair("pageNum", pageNum+""));
		params.add(new BasicNameValuePair("row", row+""));
		String resultStr = HttpClientUtil.httpConnect(url, params);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		Page<ProcessInstanceVo> page = new Page<ProcessInstanceVo>();
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			page = Utils.json2Bean(data,page,new ProcessInstanceVo());
			
			logger.info("结束远程分页查询用户【"+startUser+"】启动的流程实例列表："+page.getList().size()+" 条信息！");
		}else{
			logger.error("远程分页查询用户【"+startUser+"】启动的流程实例列表失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
		return page;
	}
	/**
	 * 获取流程的所有活动【这里只获取任务】节点的的执行情况
	 * 就相当于获取流程的审批进度
	 * @param processInstanceId ：流程实例ID
	 */
	@Override
	public List<TaskVo> queryInstanceDetail(String processInstanceId)
			throws Exception {
		String url = Utils.queryInstanceDetail;
		logger.info("开始远程查询流程的审批进度列表，远程服务地址："+url);
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("processInstanceId", processInstanceId));
		String resultStr = HttpClientUtil.httpConnect(url, params);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		List<TaskVo> list = new ArrayList<TaskVo>();
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			list = Utils.json2Bean(data,list,new TaskVo());
			
			logger.info("结束远程查询流程的审批进度列表："+list.size()+" 条信息！");
		}else{
			logger.error("远程查询流程的审批进度列表失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
		return list;
	}
	
	/**
	 * 获取某流程实例目前正在执行的任务
	 * 就相当于获取流程的审批进度
	 * @param processInstanceId ：流程实例ID
	 */
	@Override
	public List<TaskVo> queryInstanceCurrentDoingTask(String processInstanceId) throws Exception  {
		String url = Utils.queryInstanceCurrentDoingTask;
		logger.info("开始远程查询流程实例目前正在执行的任务，远程服务地址："+url);
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("processInstanceId", processInstanceId));
		String resultStr = HttpClientUtil.httpConnect(url, params);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		List<TaskVo> list = new ArrayList<TaskVo>();
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			list = Utils.json2Bean(data,list,new TaskVo());
			
			logger.info("结束远程查询某流程实例目前正在执行的任务列表："+list.size()+" 条信息！");
		}else{
			logger.error("远程查询某流程实例目前正在执行的任务失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
		return list;
	}
	
	
	/**
	 * 根据用户查询当前正在执行的任务列表
	 * <br>待办任务
	 * @param assignee ：用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 * @throws Exception
	 */
	@Override
	public Page<TaskVo> queryTaskListByAssignee(String assignee, int pageNum,
			int row) throws Exception {
		String url = Utils.queryTaskListByAssignee;
		logger.info("开始远程分页查询用户【"+assignee+"】当前正在执行的任务列表，远程服务地址："+url);
		
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("assignee", assignee));
		params.add(new BasicNameValuePair("pageNum", pageNum+""));
		params.add(new BasicNameValuePair("row", row+""));
		String resultStr = HttpClientUtil.httpConnect(url, params);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		Page<TaskVo> page = new Page<TaskVo>();
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			page = Utils.json2Bean(data,page,new TaskVo());
			
			logger.info("结束远程分页查询用户【"+assignee+"】当前正在执行的任务列表："+page.getList().size()+" 条信息！");
		}else{
			logger.error("远程分页查询用户【"+assignee+"】当前正在执行的任务列表失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
		return page;
	}
	/**
	 * 分页查询用户的已办信息，也就是用户处理过的任务
	 * <br>待办任务
	 * @param assignee ：用户ID
	 * @param pageNum
	 *            ： 待查询的页码
	 * @param row
	 *            ： 每页显示数据条数
	 * @return
	 * @throws Exception
	 */
	@Override
	public Page<TaskVo> queryHisTaskListByAssignee(String assignee,
			int pageNum, int row) throws Exception {
		String url = Utils.queryHisTaskListByAssignee;
		logger.info("开始远程分页查询用户【"+assignee+"】已办信息列表，远程服务地址："+url);
		
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("assignee", assignee));
		params.add(new BasicNameValuePair("pageNum", pageNum+""));
		params.add(new BasicNameValuePair("row", row+""));
		String resultStr = HttpClientUtil.httpConnect(url, params);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		Page<TaskVo> page = new Page<TaskVo>();
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			page = Utils.json2Bean(data,page,new TaskVo());
			
			logger.info("结束远程分页查询用户【"+assignee+"】已办信息列表："+page.getList().size()+" 条信息！");
		}else{
			logger.error("远程分页查询用户【"+assignee+"】已办信息表失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
		return page;
	}
	/**
	 * 启动流程，使用key值启动，默认就是按照最新版本的流程定义进行启动
	 * @param key ：流程的key
	 * @param startUser ： 启动流程的用户ID
	 * @param variables：流程变量
	 * @return
	 * @throws Exception
	 */
	@Override
	public ProcessInstanceVo startProcess(String key, String startUser,
			Map<String, Object> variables) throws Exception {
		String url = Utils.startProcess;
		logger.info("开始远程启动流程【"+key+"】的流程实例，远程服务地址："+url);
		
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("startUser", startUser));
		params.add(new BasicNameValuePair("key", key));
		
		if(!variables.isEmpty()){
			JSONObject json = JSONObject.fromObject(variables);
			params.add(new BasicNameValuePair("variables", json.toString()));
		}
		
		String resultStr = HttpClientUtil.httpConnect(url, params);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		ProcessInstanceVo instance = new ProcessInstanceVo();
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			instance = Utils.json2Bean(data,new ProcessInstanceVo());
			
			logger.info("结束远程启动流程实例【"+key+"】，实例ID = "+instance.getId());
			
			return instance;
		}else{
			logger.error("远程启动的流程实例【"+key+"】失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
	}
	/**
	 * 执行任务
	 * @param taskId ：任务ID
	 * @param doTaskType：执行任务的类型， 1：同意   ；0：拒绝
	 * @param variables：流程变量
	 * @param varIsBindTaskId ： 流程变量是否绑定当前任务，默认为不绑定
	 * @throws Exception
	 */
	@Override
	public void doTask(String taskId, int doTaskType,
			Map<String, Object> variables, int varIsBindTaskId)
			throws Exception {
		String url = Utils.doTask;
		logger.info("开始远程执行任务【"+taskId+"】，远程服务地址："+url);
		
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("taskId", taskId));
		params.add(new BasicNameValuePair("doTaskType", doTaskType+""));
		params.add(new BasicNameValuePair("varIsBindTaskId", varIsBindTaskId+""));
		if(!variables.isEmpty()){
			JSONObject json = JSONObject.fromObject(variables);
			params.add(new BasicNameValuePair("variables", json.toString()));
		}
		String resultStr = HttpClientUtil.httpConnect(url, params);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			Map<String, Object> map = Utils.json2Map(data);
			if(!map.isEmpty()){
				isSucceed = (String) map.get("isSucceed");
				if("1".equals(isSucceed)){
					logger.info("结束远程执行任务【"+taskId+"】，执行任务成功！");
				}else{
					logger.info("结束远程执行任务【"+taskId+"】，执行任务失败，服务器端执行出错，错误信息："+map.get("msg"));
					throw new Exception(map.get("msg")+"");
				}
			}
			
		}else{
			logger.error("远程执行任务【"+taskId+"】失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
	}
	/**
	 * 设置流程变量
	 * @param taskId ：任务ID
	 * @param variables：流程变量
	 * @param varIsBindTaskId ： 流程变量是否绑定当前任务，默认为不绑定
	 * @throws Exception
	 */
	@Override
	public void setVariables(String taskId, Map<String, Object> variables,
			boolean varIsBindTaskId) throws Exception {
		
		String url = Utils.setVariables;
		logger.info("开始远程执行任务【"+taskId+"】，远程服务地址："+url);
		
		List<NameValuePair> params = new ArrayList<>();
		params.add(new BasicNameValuePair("taskId", taskId));
		params.add(new BasicNameValuePair("varIsBindTaskId", (varIsBindTaskId ? 1 : 0)+""));
		if(!variables.isEmpty()){
			JSONObject json = JSONObject.fromObject(variables);
			params.add(new BasicNameValuePair("variables", json.toString()));
		}
		String resultStr = HttpClientUtil.httpConnect(url, params);
		JSONObject json = JSONObject.fromObject(resultStr);
		String isSucceed = (String)json.get("isSucceed");
		
		if("1".equals(isSucceed)){
			String data = json.getString("data");
			Map<String, Object> map = Utils.json2Map(data);
			if(!map.isEmpty()){
				isSucceed = (String) map.get("isSucceed");
				if("1".equals(isSucceed)){
					logger.info("结束远程设置流程变量，设置流程变量成功！");
				}else{
					logger.info("结束远程设置流程变量，设置流程变量失败，服务器端执行出错，错误信息："+map.get("msg"));
					throw new Exception(map.get("msg")+"");
				}
			}
			
		}else{
			logger.error("远程设置流程变量失败，失败信息："+json.getString("msg"));
			throw new Exception(json.getString("msg"));
		}
	}

}
