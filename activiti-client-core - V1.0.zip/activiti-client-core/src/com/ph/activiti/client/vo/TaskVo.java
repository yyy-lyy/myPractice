package com.ph.activiti.client.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class TaskVo {

	 public static final String DELETE_REASON_COMPLETED = "completed";
	  public static final String DELETE_REASON_DELETED = "deleted";
	  public static final int DEFAULT_PRIORITY = 50;
	  
	  private int revision;

	  private String owner;
	  private String assignee;
	  private String initialAssignee;
//	  private DelegationState delegationState;
	  
	  private String parentTaskId;
	  
	  private String name;
	  private String localizedName;
	  private String description;
	  private String localizedDescription;
	  private int priority = DEFAULT_PRIORITY;
	  private Date createTime; // The time when the task has been created
	  private Date dueDate;
//	  private int suspensionState = SuspensionState.ACTIVE.getStateCode();
	  private String category;
	  
	  private boolean isIdentityLinksInitialized = false;
	  private List<IdentityLinkEntity> taskIdentityLinkEntities = new ArrayList<IdentityLinkEntity>(); 
	  
	  private String executionId;
	  private ProcessInstanceVo execution;
	  
	  private String processInstanceId;
	  private ProcessInstanceVo processInstance;
	  
	  private String processDefinitionId;
	  
//	  private TaskDefinition taskDefinition;
	  private String taskDefinitionKey;
	  private String formKey;
	  
	  private boolean isDeleted;
	  
	  private String eventName;
	  
	  private String tenantId = "";//ProcessEngineConfiguration.NO_TENANT_ID;
	  
	  private List<VariableVo> queryVariables;
	  
	  private boolean forcedUpdate;
	  
	  private String id;
	  private String processDefinitionKey;
	  private String processDefinitionName;
	  private Integer processDefinitionVersion;
	  private String deploymentId;
	  private Date startTime;
	  private Date endTime;
	  private Long durationInMillis;
	  private String deleteReason;
	  
	  private Map<String, String> variables;

	public int getRevision() {
		return revision;
	}

	public void setRevision(int revision) {
		this.revision = revision;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getInitialAssignee() {
		return initialAssignee;
	}

	public void setInitialAssignee(String initialAssignee) {
		this.initialAssignee = initialAssignee;
	}

	public String getParentTaskId() {
		return parentTaskId;
	}

	public void setParentTaskId(String parentTaskId) {
		this.parentTaskId = parentTaskId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocalizedName() {
		return localizedName;
	}

	public void setLocalizedName(String localizedName) {
		this.localizedName = localizedName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocalizedDescription() {
		return localizedDescription;
	}

	public void setLocalizedDescription(String localizedDescription) {
		this.localizedDescription = localizedDescription;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isIdentityLinksInitialized() {
		return isIdentityLinksInitialized;
	}

	public void setIdentityLinksInitialized(boolean isIdentityLinksInitialized) {
		this.isIdentityLinksInitialized = isIdentityLinksInitialized;
	}

	public List<IdentityLinkEntity> getTaskIdentityLinkEntities() {
		return taskIdentityLinkEntities;
	}

	public void setTaskIdentityLinkEntities(
			List<IdentityLinkEntity> taskIdentityLinkEntities) {
		this.taskIdentityLinkEntities = taskIdentityLinkEntities;
	}

	public String getExecutionId() {
		return executionId;
	}

	public void setExecutionId(String executionId) {
		this.executionId = executionId;
	}

	public ProcessInstanceVo getExecution() {
		return execution;
	}

	public void setExecution(ProcessInstanceVo execution) {
		this.execution = execution;
	}

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public ProcessInstanceVo getProcessInstance() {
		return processInstance;
	}

	public void setProcessInstance(ProcessInstanceVo processInstance) {
		this.processInstance = processInstance;
	}

	public String getProcessDefinitionId() {
		return processDefinitionId;
	}

	public void setProcessDefinitionId(String processDefinitionId) {
		this.processDefinitionId = processDefinitionId;
	}

	public String getTaskDefinitionKey() {
		return taskDefinitionKey;
	}

	public void setTaskDefinitionKey(String taskDefinitionKey) {
		this.taskDefinitionKey = taskDefinitionKey;
	}

	public String getFormKey() {
		return formKey;
	}

	public void setFormKey(String formKey) {
		this.formKey = formKey;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public List<VariableVo> getQueryVariables() {
		return queryVariables;
	}

	public void setQueryVariables(List<VariableVo> queryVariables) {
		this.queryVariables = queryVariables;
	}

	public boolean isForcedUpdate() {
		return forcedUpdate;
	}

	public void setForcedUpdate(boolean forcedUpdate) {
		this.forcedUpdate = forcedUpdate;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProcessDefinitionKey() {
		return processDefinitionKey;
	}

	public void setProcessDefinitionKey(String processDefinitionKey) {
		this.processDefinitionKey = processDefinitionKey;
	}

	public String getProcessDefinitionName() {
		return processDefinitionName;
	}

	public void setProcessDefinitionName(String processDefinitionName) {
		this.processDefinitionName = processDefinitionName;
	}

	public Integer getProcessDefinitionVersion() {
		return processDefinitionVersion;
	}

	public void setProcessDefinitionVersion(Integer processDefinitionVersion) {
		this.processDefinitionVersion = processDefinitionVersion;
	}

	public String getDeploymentId() {
		return deploymentId;
	}

	public void setDeploymentId(String deploymentId) {
		this.deploymentId = deploymentId;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Long getDurationInMillis() {
		return durationInMillis;
	}

	public void setDurationInMillis(Long durationInMillis) {
		this.durationInMillis = durationInMillis;
	}

	public String getDeleteReason() {
		return deleteReason;
	}

	public void setDeleteReason(String deleteReason) {
		this.deleteReason = deleteReason;
	}

	@Override
	public String toString() {
		return "TaskVo [revision=" + revision + ", owner=" + owner
				+ ", assignee=" + assignee + ", initialAssignee="
				+ initialAssignee + ", parentTaskId=" + parentTaskId
				+ ", name=" + name + ", localizedName=" + localizedName
				+ ", description=" + description + ", localizedDescription="
				+ localizedDescription + ", priority=" + priority
				+ ", createTime=" + createTime + ", dueDate=" + dueDate
				+ ", category=" + category + ", isIdentityLinksInitialized="
				+ isIdentityLinksInitialized + ", taskIdentityLinkEntities="
				+ taskIdentityLinkEntities + ", executionId=" + executionId
				+ ", execution=" + execution + ", processInstanceId="
				+ processInstanceId + ", processInstance=" + processInstance
				+ ", processDefinitionId=" + processDefinitionId
				+ ", taskDefinitionKey=" + taskDefinitionKey + ", formKey="
				+ formKey + ", isDeleted=" + isDeleted + ", eventName="
				+ eventName + ", tenantId=" + tenantId + ", queryVariables="
				+ queryVariables + ", forcedUpdate=" + forcedUpdate + ", id="
				+ id + ", processDefinitionKey=" + processDefinitionKey
				+ ", processDefinitionName=" + processDefinitionName
				+ ", processDefinitionVersion=" + processDefinitionVersion
				+ ", deploymentId=" + deploymentId + ", startTime=" + startTime
				+ ", endTime=" + endTime + ", durationInMillis="
				+ durationInMillis + ", deleteReason=" + deleteReason
				+ ", getRevision()=" + getRevision() + ", getOwner()="
				+ getOwner() + ", getAssignee()=" + getAssignee()
				+ ", getInitialAssignee()=" + getInitialAssignee()
				+ ", getParentTaskId()=" + getParentTaskId() + ", getName()="
				+ getName() + ", getLocalizedName()=" + getLocalizedName()
				+ ", getDescription()=" + getDescription()
				+ ", getLocalizedDescription()=" + getLocalizedDescription()
				+ ", getPriority()=" + getPriority() + ", getCreateTime()="
				+ getCreateTime() + ", getDueDate()=" + getDueDate()
				+ ", getCategory()=" + getCategory()
				+ ", isIdentityLinksInitialized()="
				+ isIdentityLinksInitialized()
				+ ", getTaskIdentityLinkEntities()="
				+ getTaskIdentityLinkEntities() + ", getExecutionId()="
				+ getExecutionId() + ", getExecution()=" + getExecution()
				+ ", getProcessInstanceId()=" + getProcessInstanceId()
				+ ", getProcessInstance()=" + getProcessInstance()
				+ ", getProcessDefinitionId()=" + getProcessDefinitionId()
				+ ", getTaskDefinitionKey()=" + getTaskDefinitionKey()
				+ ", getFormKey()=" + getFormKey() + ", isDeleted()="
				+ isDeleted() + ", getEventName()=" + getEventName()
				+ ", getTenantId()=" + getTenantId() + ", getQueryVariables()="
				+ getQueryVariables() + ", isForcedUpdate()="
				+ isForcedUpdate() + ", getId()=" + getId()
				+ ", getProcessDefinitionKey()=" + getProcessDefinitionKey()
				+ ", getProcessDefinitionName()=" + getProcessDefinitionName()
				+ ", getProcessDefinitionVersion()="
				+ getProcessDefinitionVersion() + ", getDeploymentId()="
				+ getDeploymentId() + ", getStartTime()=" + getStartTime()
				+ ", getEndTime()=" + getEndTime() + ", getDurationInMillis()="
				+ getDurationInMillis() + ", getDeleteReason()="
				+ getDeleteReason() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	public Map<String, String> getVariables() {
		return variables;
	}

	public void setVariables(Map<String, String> variables) {
		this.variables = variables;
	}
	  
	  
}
