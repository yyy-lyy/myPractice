package com.ph.activiti.client.vo;

public class StartingExecution {
	 
	  protected final ActivityVo selectedInitial;

	  public StartingExecution(ActivityVo selectedInitial) {
	    this.selectedInitial = selectedInitial;
	  }

	  public ActivityVo getInitial() {
	    return selectedInitial;
	  }
	  
}
