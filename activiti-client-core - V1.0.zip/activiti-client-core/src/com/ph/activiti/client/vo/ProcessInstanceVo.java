package com.ph.activiti.client.vo;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 自定义流程实例类，正在执行的流程和历史实例，都是这个类
 * 
 * @author yangyunyun
 *
 */
public class ProcessInstanceVo {

	private String endActivityId;
	private String startUserId;
	private String startActivityId;
	private String superProcessInstanceId;
	private String id;
	private Date startTime;
	private Date endTime;
	private Long durationInMillis;
	
	  
	  // current position /////////////////////////////////////////////////////////
	  
	  private Map<String, VariableVo> variableInstances = null; // needs to be null, the logic depends on it for checking if vars were already fetched
	  
	  // The cache is used when fetching/setting specific variables
	  private Map<String, VariableVo> usedVariablesCache = new HashMap<String, VariableVo>();
	  
//	  private ELContext cachedElContext;

	  
	  private ProcessDefinitionVo processDefinition;

	  /** current activity */
	  private ActivityVo activity;
	  
	  /** current transition.  is null when there is no transition being taken. */
	  private TransitionVo transition = null;
	  
	  /** transition that will be taken.  is null when there is no transition being taken. */
	  private TransitionVo transitionBeingTaken = null;

	  /** the process instance.  this is the root of the execution tree.  
	   * the processInstance of a process instance is a self reference. */
	  private ProcessInstanceVo processInstance;
	  
	  /** the parent execution */
	  private ProcessInstanceVo parent;
	  
	  /** nested executions representing scopes or concurrent paths */
	  private List<ProcessInstanceVo> executions;
	  
	  /** super execution, not-null if this execution is part of a subprocess */
	  private ProcessInstanceVo superExecution;
	  
	  /** reference to a subprocessinstance, not-null if currently subprocess is started from this execution */
	  private ProcessInstanceVo subProcessInstance;
	  
	  private StartingExecution startingExecution;
	  
	  /** The tenant identifier (if any) */
	  private String tenantId = "";//ProcessEngineConfiguration.NO_TENANT_ID;
	  private String name;
	  private String description;
	  private String localizedName;
	  private String localizedDescription;
	  
	  private Date lockTime;
	  
	  // state/type of execution ////////////////////////////////////////////////// 
	  
	  /** indicates if this execution represents an active path of execution.
	   * Executions are made inactive in the following situations:
	   * <ul>
	   *   <li>an execution enters a nested scope</li>
	   *   <li>an execution is split up into multiple concurrent executions, then the parent is made inactive.</li>
	   *   <li>an execution has arrived in a parallel gateway or join and that join has not yet activated/fired.</li>
	   *   <li>an execution is ended.</li>
	   * </ul>*/ 
	  private boolean isActive = true;
	  private boolean isScope = true;
	  private boolean isConcurrent = false;
	  private boolean isEnded = false;
	  private boolean isEventScope = false;
	  
	  // events ///////////////////////////////////////////////////////////////////
	  
	  private String eventName;
//	  private PvmProcessElement eventSource;
	  private int executionListenerIndex = 0;
	  
	  // associated entities /////////////////////////////////////////////////////
	  
	  // (we cache associated entities here to minimize db queries) 
//	  private List<EventSubscriptionEntity> eventSubscriptions;  
//	  private List<JobEntity> jobs;
	  private List<TaskVo> tasks;
	  private List<IdentityLinkEntity> identityLinks;
	  private int cachedEntityState;
	  
	  // cascade deletion ////////////////////////////////////////////////////////
	  
	  private boolean deleteRoot;
	  private String deleteReason;
	  
	  // replaced by //////////////////////////////////////////////////////////////
	  
	  /** when execution structure is pruned during a takeAll, then 
	   * the original execution has to be resolved to the replaced execution.
	   * @see {@link #takeAll(List, List)} {@link OutgoingExecution} */
	  private ProcessInstanceVo replacedBy;
	  
	  // atomic operations ////////////////////////////////////////////////////////

	  /** next operation.  process execution is in fact runtime interpretation of the process model.
	   * each operation is a logical unit of interpretation of the process.  so sequentially processing 
	   * the operations drives the interpretation or execution of a process. 
	   * @see AtomicOperation
	   * @see #performOperation(AtomicOperation) */
//	  private AtomicOperation nextOperation;
	  private boolean isOperating = false;

	  private int revision = 1;
//	  private int suspensionState = SuspensionState.ACTIVE.getStateCode();

	  /**
	   * persisted reference to the processDefinition.
	   * 
	   * @see #processDefinition
	   * @see #setProcessDefinition(ProcessDefinitionImpl)
	   * @see #getProcessDefinition()
	   */
	  private String processDefinitionId;
	  
	  /**
	   * persisted reference to the process definition key.
	   */
	  private String processDefinitionKey;
	  
	  /**
	   * persisted reference to the process definition name.
	   */
	  private String processDefinitionName;
	  
	  /**
	   * persisted reference to the process definition version.
	   */
	  private Integer processDefinitionVersion;
	  
	  /**
	   * persisted reference to the deployment id.
	   */
	  private String deploymentId;
	  /**
	   * persisted reference to the current position in the diagram within the
	   * {@link #processDefinition}.
	   * 
	   * @see #activity
	   * @see #setActivity(ActivityImpl)
	   * @see #getActivity()
	   */
	  private String activityId;
	  /**
	   * The name of the current activity position
	   */
	  private String activityName;
	  /**
	   * persisted reference to the process instance.
	   * 
	   * @see #getProcessInstance()
	   */
	  private String processInstanceId;
	  /**
	   * persisted reference to the business key.
	   */
	  private String businessKey;
	  /**
	   * persisted reference to the parent of this execution.
	   * 
	   * @see #getParent()
	   * @see #setParentId(String)
	   */
	  private String parentId;
	  
	  /**
	   * persisted reference to the super execution of this execution
	   * 
	   * @See {@link #getSuperExecution()}
	   * @see #setSuperExecution(ExecutionEntity)
	   */
	  private String superExecutionId;
	  private boolean forcedUpdate;
	  private List<VariableVo> queryVariables;
	  
	  
	  private Map<String,String> variables = new HashMap<String,String>();
	  
	public String getEndActivityId() {
		return endActivityId;
	}
	public void setEndActivityId(String endActivityId) {
		this.endActivityId = endActivityId;
	}
	public String getStartUserId() {
		return startUserId;
	}
	public void setStartUserId(String startUserId) {
		this.startUserId = startUserId;
	}
	public String getStartActivityId() {
		return startActivityId;
	}
	public void setStartActivityId(String startActivityId) {
		this.startActivityId = startActivityId;
	}
	public String getSuperProcessInstanceId() {
		return superProcessInstanceId;
	}
	public void setSuperProcessInstanceId(String superProcessInstanceId) {
		this.superProcessInstanceId = superProcessInstanceId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public Long getDurationInMillis() {
		return durationInMillis;
	}
	public void setDurationInMillis(Long durationInMillis) {
		this.durationInMillis = durationInMillis;
	}
	public Map<String, VariableVo> getVariableInstances() {
		return variableInstances;
	}
	public void setVariableInstances(Map<String, VariableVo> variableInstances) {
		this.variableInstances = variableInstances;
	}
	public Map<String, VariableVo> getUsedVariablesCache() {
		return usedVariablesCache;
	}
	public void setUsedVariablesCache(Map<String, VariableVo> usedVariablesCache) {
		this.usedVariablesCache = usedVariablesCache;
	}
	public ProcessDefinitionVo getProcessDefinition() {
		return processDefinition;
	}
	public void setProcessDefinition(ProcessDefinitionVo processDefinition) {
		this.processDefinition = processDefinition;
	}
	public ActivityVo getActivity() {
		return activity;
	}
	public void setActivity(ActivityVo activity) {
		this.activity = activity;
	}
	public TransitionVo getTransition() {
		return transition;
	}
	public void setTransition(TransitionVo transition) {
		this.transition = transition;
	}
	public TransitionVo getTransitionBeingTaken() {
		return transitionBeingTaken;
	}
	public void setTransitionBeingTaken(TransitionVo transitionBeingTaken) {
		this.transitionBeingTaken = transitionBeingTaken;
	}
	public ProcessInstanceVo getProcessInstance() {
		return processInstance;
	}
	public void setProcessInstance(ProcessInstanceVo processInstance) {
		this.processInstance = processInstance;
	}
	public ProcessInstanceVo getParent() {
		return parent;
	}
	public void setParent(ProcessInstanceVo parent) {
		this.parent = parent;
	}
	public List<ProcessInstanceVo> getExecutions() {
		return executions;
	}
	public void setExecutions(List<ProcessInstanceVo> executions) {
		this.executions = executions;
	}
	public ProcessInstanceVo getSuperExecution() {
		return superExecution;
	}
	public void setSuperExecution(ProcessInstanceVo superExecution) {
		this.superExecution = superExecution;
	}
	public ProcessInstanceVo getSubProcessInstance() {
		return subProcessInstance;
	}
	public void setSubProcessInstance(ProcessInstanceVo subProcessInstance) {
		this.subProcessInstance = subProcessInstance;
	}
	public StartingExecution getStartingExecution() {
		return startingExecution;
	}
	public void setStartingExecution(StartingExecution startingExecution) {
		this.startingExecution = startingExecution;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLocalizedName() {
		return localizedName;
	}
	public void setLocalizedName(String localizedName) {
		this.localizedName = localizedName;
	}
	public String getLocalizedDescription() {
		return localizedDescription;
	}
	public void setLocalizedDescription(String localizedDescription) {
		this.localizedDescription = localizedDescription;
	}
	public Date getLockTime() {
		return lockTime;
	}
	public void setLockTime(Date lockTime) {
		this.lockTime = lockTime;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public boolean isScope() {
		return isScope;
	}
	public void setScope(boolean isScope) {
		this.isScope = isScope;
	}
	public boolean isConcurrent() {
		return isConcurrent;
	}
	public void setConcurrent(boolean isConcurrent) {
		this.isConcurrent = isConcurrent;
	}
	public boolean isEnded() {
		return isEnded;
	}
	public void setEnded(boolean isEnded) {
		this.isEnded = isEnded;
	}
	public boolean isEventScope() {
		return isEventScope;
	}
	public void setEventScope(boolean isEventScope) {
		this.isEventScope = isEventScope;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public int getExecutionListenerIndex() {
		return executionListenerIndex;
	}
	public void setExecutionListenerIndex(int executionListenerIndex) {
		this.executionListenerIndex = executionListenerIndex;
	}
	public List<TaskVo> getTasks() {
		return tasks;
	}
	public void setTasks(List<TaskVo> tasks) {
		this.tasks = tasks;
	}
	public List<IdentityLinkEntity> getIdentityLinks() {
		return identityLinks;
	}
	public void setIdentityLinks(List<IdentityLinkEntity> identityLinks) {
		this.identityLinks = identityLinks;
	}
	public int getCachedEntityState() {
		return cachedEntityState;
	}
	public void setCachedEntityState(int cachedEntityState) {
		this.cachedEntityState = cachedEntityState;
	}
	public boolean isDeleteRoot() {
		return deleteRoot;
	}
	public void setDeleteRoot(boolean deleteRoot) {
		this.deleteRoot = deleteRoot;
	}
	public String getDeleteReason() {
		return deleteReason;
	}
	public void setDeleteReason(String deleteReason) {
		this.deleteReason = deleteReason;
	}
	public ProcessInstanceVo getReplacedBy() {
		return replacedBy;
	}
	public void setReplacedBy(ProcessInstanceVo replacedBy) {
		this.replacedBy = replacedBy;
	}
	public boolean isOperating() {
		return isOperating;
	}
	public void setOperating(boolean isOperating) {
		this.isOperating = isOperating;
	}
	public int getRevision() {
		return revision;
	}
	public void setRevision(int revision) {
		this.revision = revision;
	}
	public String getProcessDefinitionId() {
		return processDefinitionId;
	}
	public void setProcessDefinitionId(String processDefinitionId) {
		this.processDefinitionId = processDefinitionId;
	}
	public String getProcessDefinitionKey() {
		return processDefinitionKey;
	}
	public void setProcessDefinitionKey(String processDefinitionKey) {
		this.processDefinitionKey = processDefinitionKey;
	}
	public String getProcessDefinitionName() {
		return processDefinitionName;
	}
	public void setProcessDefinitionName(String processDefinitionName) {
		this.processDefinitionName = processDefinitionName;
	}
	public Integer getProcessDefinitionVersion() {
		return processDefinitionVersion;
	}
	public void setProcessDefinitionVersion(Integer processDefinitionVersion) {
		this.processDefinitionVersion = processDefinitionVersion;
	}
	public String getDeploymentId() {
		return deploymentId;
	}
	public void setDeploymentId(String deploymentId) {
		this.deploymentId = deploymentId;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getProcessInstanceId() {
		return processInstanceId;
	}
	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}
	public String getBusinessKey() {
		return businessKey;
	}
	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getSuperExecutionId() {
		return superExecutionId;
	}
	public void setSuperExecutionId(String superExecutionId) {
		this.superExecutionId = superExecutionId;
	}
	public boolean isForcedUpdate() {
		return forcedUpdate;
	}
	public void setForcedUpdate(boolean forcedUpdate) {
		this.forcedUpdate = forcedUpdate;
	}
	public List<VariableVo> getQueryVariables() {
		return queryVariables;
	}
	public void setQueryVariables(List<VariableVo> queryVariables) {
		this.queryVariables = queryVariables;
	}
	@Override
	public String toString() {
		return "ProcessInstanceVo [endActivityId=" + endActivityId
				+ ", startUserId=" + startUserId + ", startActivityId="
				+ startActivityId + ", superProcessInstanceId="
				+ superProcessInstanceId + ", id=" + id + ", startTime="
				+ startTime + ", endTime=" + endTime + ", durationInMillis="
				+ durationInMillis + ", variableInstances=" + variableInstances
				+ ", usedVariablesCache=" + usedVariablesCache
				+ ", processDefinition=" + processDefinition + ", activity="
				+ activity + ", transition=" + transition
				+ ", transitionBeingTaken=" + transitionBeingTaken
				+ ", processInstance=" + processInstance + ", parent=" + parent
				+ ", executions=" + executions + ", superExecution="
				+ superExecution + ", subProcessInstance=" + subProcessInstance
				+ ", startingExecution=" + startingExecution + ", tenantId="
				+ tenantId + ", name=" + name + ", description=" + description
				+ ", localizedName=" + localizedName
				+ ", localizedDescription=" + localizedDescription
				+ ", lockTime=" + lockTime + ", isActive=" + isActive
				+ ", isScope=" + isScope + ", isConcurrent=" + isConcurrent
				+ ", isEnded=" + isEnded + ", isEventScope=" + isEventScope
				+ ", eventName=" + eventName + ", executionListenerIndex="
				+ executionListenerIndex + ", tasks=" + tasks
				+ ", identityLinks=" + identityLinks + ", cachedEntityState="
				+ cachedEntityState + ", deleteRoot=" + deleteRoot
				+ ", deleteReason=" + deleteReason + ", replacedBy="
				+ replacedBy + ", isOperating=" + isOperating + ", revision="
				+ revision + ", processDefinitionId=" + processDefinitionId
				+ ", processDefinitionKey=" + processDefinitionKey
				+ ", processDefinitionName=" + processDefinitionName
				+ ", processDefinitionVersion=" + processDefinitionVersion
				+ ", deploymentId=" + deploymentId + ", activityId="
				+ activityId + ", activityName=" + activityName
				+ ", processInstanceId=" + processInstanceId + ", businessKey="
				+ businessKey + ", parentId=" + parentId
				+ ", superExecutionId=" + superExecutionId + ", forcedUpdate="
				+ forcedUpdate + ", queryVariables=" + queryVariables + "]";
	}
	public Map<String,String> getVariables() {
		return variables;
	}
	public void setVariables(Map<String,String> variables) {
		this.variables = variables;
	}
	
}
