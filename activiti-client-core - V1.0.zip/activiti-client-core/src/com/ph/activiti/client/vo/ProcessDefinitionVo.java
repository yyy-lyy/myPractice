package com.ph.activiti.client.vo;

import java.util.Map;
/**
 * 自定义流程定义实体类
 * @author yangyunyun
 *
 */
public class ProcessDefinitionVo {
	private int revision = 1;
	private String key;
	private int version;
	private String category;
	private String deploymentId;
	private String resourceName;
	private String tenantId = "";// ProcessEngineConfiguration.NO_TENANT_ID;
	private Integer historyLevel;
	private String diagramResourceName;
	private boolean isGraphicalNotationDefined;
	private Map<String, Object> variables;
	private boolean hasStartFormKey;
	private int suspensionState = 1;// SuspensionState.ACTIVE.getStateCode();
	private boolean isIdentityLinksInitialized = false;
	private String name;
	private String description;
	private String id;
	private Map<String, Object> properties;
	// protected StartFormHandler startFormHandler;
	// protected Map<String, TaskDefinition> taskDefinitions;
	// protected List<IdentityLinkEntity> definitionIdentityLinkEntities = new
	// ArrayList<IdentityLinkEntity>();
	// protected Set<Expression> candidateStarterUserIdExpressions = new
	// HashSet<Expression>();
	// protected Set<Expression> candidateStarterGroupIdExpressions = new
	// HashSet<Expression>();
	// protected transient ActivitiEventSupport eventSupport;
	// protected ActivityImpl initial;
	// protected Map<ActivityImpl, List<ActivityImpl>> initialActivityStacks =
	// new HashMap<ActivityImpl, List<ActivityImpl>>();
	// protected List<LaneSet> laneSets;
	// protected ParticipantProcess participantProcess;
	// protected List<ActivityImpl> activities = new ArrayList<ActivityImpl>();
	// protected Map<String, ActivityImpl> namedActivities = new HashMap<String,
	// ActivityImpl>();
	// protected Map<String, List<ExecutionListener>> executionListeners = new
	// HashMap<String, List<ExecutionListener>>();
	// protected IOSpecification ioSpecification;
	// @JsonIgnore
	// protected ProcessDefinitionImpl processDefinition;

//	public ProcessDefinitionVo(ProcessDefinition processDefinition) {
//		this.version = processDefinition.getVersion();
//		this.key = processDefinition.getKey();
//		this.category = processDefinition.getCategory();
//		this.deploymentId = processDefinition.getDeploymentId();
//		this.resourceName = processDefinition.getResourceName();
//		this.tenantId = processDefinition.getTenantId();
//		this.diagramResourceName = processDefinition.getDiagramResourceName();
//		this.isGraphicalNotationDefined = processDefinition.hasGraphicalNotation();
//		this.hasStartFormKey = processDefinition.hasStartFormKey();
//		this.name = processDefinition.getName();
//		this.description = processDefinition.getDescription();
//		this.id = processDefinition.getId();
		// this.revision = processDefinition.getRev
		// this.historyLevel = processDefinition.geth
		// this.startFormHandler = processDefinition.gets
		// this.taskDefinitions = processDefinition.isSuspended()
		// this.variables = processDefinition
		// this.suspensionState = processDefinition.gets
		// this.isIdentityLinksInitialized = processDefinition.isSuspended()
		// this.definitionIdentityLinkEntities = processDefinition.getd
		// this.candidateStarterUserIdExpressions = processDefinition.getc
		// this.candidateStarterGroupIdExpressions = processDefinition.
		// this.eventSupport = processDefinition.gete
		// this.initial = processDefinition.ini;
		// this.initialActivityStacks = processDefinition.get;
		// this.laneSets = processDefinition.l;
		// this.participantProcess = processDefinition.getpa;
		// this.activities = processDefinition.geta;
		// this.namedActivities = processDefinition.getn;
		// this.executionListeners = processDefinition.gete;
		// this.ioSpecification = processDefinition.geti;
		// this.properties = processDefinition.p;
//	}

	public int getRevision() {
		return revision;
	}

	public void setRevision(int revision) {
		this.revision = revision;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDeploymentId() {
		return deploymentId;
	}

	public void setDeploymentId(String deploymentId) {
		this.deploymentId = deploymentId;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public Integer getHistoryLevel() {
		return historyLevel;
	}

	public void setHistoryLevel(Integer historyLevel) {
		this.historyLevel = historyLevel;
	}

	public String getDiagramResourceName() {
		return diagramResourceName;
	}

	public void setDiagramResourceName(String diagramResourceName) {
		this.diagramResourceName = diagramResourceName;
	}

	public boolean isGraphicalNotationDefined() {
		return isGraphicalNotationDefined;
	}

	public void setGraphicalNotationDefined(boolean isGraphicalNotationDefined) {
		this.isGraphicalNotationDefined = isGraphicalNotationDefined;
	}

	public Map<String, Object> getVariables() {
		return variables;
	}

	public void setVariables(Map<String, Object> variables) {
		this.variables = variables;
	}

	public boolean isHasStartFormKey() {
		return hasStartFormKey;
	}

	public void setHasStartFormKey(boolean hasStartFormKey) {
		this.hasStartFormKey = hasStartFormKey;
	}

	public int getSuspensionState() {
		return suspensionState;
	}

	public void setSuspensionState(int suspensionState) {
		this.suspensionState = suspensionState;
	}

	public boolean isIdentityLinksInitialized() {
		return isIdentityLinksInitialized;
	}

	public void setIdentityLinksInitialized(boolean isIdentityLinksInitialized) {
		this.isIdentityLinksInitialized = isIdentityLinksInitialized;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Map<String, Object> getProperties() {
		return properties;
	}

	public void setProperties(Map<String, Object> properties) {
		this.properties = properties;
	}

	@Override
	public String toString() {
		return "ProcessDefinitionVo [revision=" + revision + ", key=" + key
				+ ", version=" + version + ", category=" + category
				+ ", deploymentId=" + deploymentId + ", resourceName="
				+ resourceName + ", tenantId=" + tenantId + ", historyLevel="
				+ historyLevel + ", diagramResourceName=" + diagramResourceName
				+ ", isGraphicalNotationDefined=" + isGraphicalNotationDefined
				+ ", variables=" + variables + ", hasStartFormKey="
				+ hasStartFormKey + ", suspensionState=" + suspensionState
				+ ", isIdentityLinksInitialized=" + isIdentityLinksInitialized
				+ ", name=" + name + ", description=" + description + ", id="
				+ id + ", properties=" + properties + "]";
	}
	
	

}
