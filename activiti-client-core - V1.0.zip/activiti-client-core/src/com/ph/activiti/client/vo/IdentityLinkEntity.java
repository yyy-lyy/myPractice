package com.ph.activiti.client.vo;


public class IdentityLinkEntity {

	  private String id;
	  
	  private String type;
	  
	  private String userId;
	  
	  private String groupId;
	  
	  private String taskId;
	  
	  private String processInstanceId;
	  
	  private String processDefId;
	  
	  private TaskVo task;
	  
	  private ProcessInstanceVo processInstance;
	  
	  private ProcessDefinitionVo processDef;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public String getProcessDefId() {
		return processDefId;
	}

	public void setProcessDefId(String processDefId) {
		this.processDefId = processDefId;
	}

	public TaskVo getTask() {
		return task;
	}

	public void setTask(TaskVo task) {
		this.task = task;
	}

	public ProcessInstanceVo getProcessInstance() {
		return processInstance;
	}

	public void setProcessInstance(ProcessInstanceVo processInstance) {
		this.processInstance = processInstance;
	}

	public ProcessDefinitionVo getProcessDef() {
		return processDef;
	}

	public void setProcessDef(ProcessDefinitionVo processDef) {
		this.processDef = processDef;
	}
	  
	  
	  
}
