package com.ph.activiti.client.demo;

import com.ph.activiti.client.utils.Utils;


public class Demo {

	public static void main(String[] args) throws Exception {
		
		
		System.out.println(Utils.baseUrl);
		
		
//		
//		PhActivitiService service = new PhActivitiServiceImpl();
//		
////		List<ProcessDefinitionVo> list = service.queryAllProcessDefinition();
////		Page<ProcessInstanceVo> page = service.queryProcessInstancesListPageByStartUser("lyy", 1, 10);
////		List<TaskVo> list = service.queryInstanceDetail("85001");
////		Page<TaskVo> page = service.queryTaskListByAssignee("lyy", 1, 10);
////		Page<TaskVo> page = service.queryHisTaskListByAssignee("zs", 1, 10);
//		
//		Map<String,Object> variables = new HashMap<>();
////		variables.put("startUser", "lyy");
////		variables.put("applyUser", "lyy");
////		variables.put("applyMoney", 11112);
////		variables.put("borrowUse", "哔哔哔哔哔哔哔哔哔哔");
////		variables.put("returnDay", 3);
////		variables.put("applyDate", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
////		//创建一个业务编号
////		String businessNum = ""+new Random().nextLong();
////		variables.put("businessNum", businessNum);
////		
////		ProcessInstanceVo startProcess = service.startProcess("借款流程", "lyy", variables);
//		
////		System.out.println(list);
////		System.out.println(page.getList());
////		System.out.println(startProcess);
//		variables.put("taskResult", "审批通过");
//		variables.put("opinion", "的点AAAAAAAAAAAAA点滴滴");
//		service.doTask("107505", 1, variables, 1);
//		
//		
//		CloseableHttpClient httpclient = HttpClients.createDefault();
//
//		try {
////			HttpGet httpGet = new HttpGet(
////					"http://localhost:8081/demo/mvc/phProcess/queryAllProcessDefinition.do");
////			CloseableHttpResponse response1 = httpclient.execute(httpGet);
////			try {
////				System.out.println(response1.getStatusLine());
////				HttpEntity entity1 = response1.getEntity();
////				EntityUtils.consume(entity1);
////			} finally {
////				response1.close();
////			}
//
//			HttpPost httpPost = new HttpPost("http://localhost:8081/demo/mvc/phProcess/queryAllProcessDefinition.do");
//			List<NameValuePair> nvps = new ArrayList<NameValuePair>();
//			nvps.add(new BasicNameValuePair("username", "vip"));
//			nvps.add(new BasicNameValuePair("password", "secret"));
//			httpPost.setEntity(new UrlEncodedFormEntity(nvps,"utf-8"));
//			
//			CloseableHttpResponse response2 = httpclient.execute(httpPost);
//
//			try {
//				System.out.println(response2.getStatusLine());
//				HttpEntity entity2 = response2.getEntity();
////				EntityUtils.consume(entity2);
//				
//				InputStream is = entity2.getContent();
//				ByteArrayOutputStream baos = new ByteArrayOutputStream();
//				byte[] buffer = new byte[1024];
//				int len = -1;
//				while ((len = is.read(buffer)) != -1) {
//					baos.write(buffer, 0, len);
//				}
//				
//				String result = baos.toString();
//				
//				System.out.println(result);
//
//				baos.close();
//				
//			} finally {
//				response2.close();
//			}
//		} finally {
//			httpclient.close();
//		}
	}
}