package com.ph.activiti.client.utils;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 工具类
 * 
 * @author yangyunyun
 *
 */
public class Utils {

	private static ObjectMapper objectMapper = new ObjectMapper();
	private static Logger logger = Logger.getLogger(Utils.class);
	
	public static String queryAllProcessDefinitionUrl = "/mvc/phProcess/queryAllProcessDefinition.do";
	public static String queryProcessInstancesListPageByStartUser = "/mvc/phProcess/queryProcessInstancesListPageByStartUser.do";
	public static String queryInstanceDetail = "/mvc/phProcess/queryInstanceDetail.do";
	public static String queryInstanceCurrentDoingTask = "/mvc/phProcess/queryInstanceCurrentDoingTask.do";
	public static String queryTaskListByAssignee = "/mvc/phProcess/queryTaskListByAssignee.do";
	public static String queryHisTaskListByAssignee = "/mvc/phProcess/queryHisTaskListByAssignee.do";
	public static String startProcess = "/mvc/phProcess/startProcess.do";
	public static String doTask = "/mvc/phProcess/doTask.do";
	public static String setVariables = "/mvc/phProcess/setVariables.do";
	public static int timeout = 50000;
	public static String baseUrl = "http://localhost:8081/demo";

	static {
		try {
			Properties properties = new Properties();
			InputStream in = Utils.class.getClassLoader().getResourceAsStream("httpUrl.properties");
			properties.load(in);

			queryAllProcessDefinitionUrl = properties
					.getProperty("queryAllProcessDefinitionUrl");
			queryProcessInstancesListPageByStartUser = properties
					.getProperty("queryProcessInstancesListPageByStartUser");
			queryInstanceDetail = properties.getProperty("queryInstanceDetail");
			queryInstanceCurrentDoingTask = properties
					.getProperty("queryInstanceCurrentDoingTask");
			queryTaskListByAssignee = properties
					.getProperty("queryTaskListByAssignee");
			queryHisTaskListByAssignee = properties
					.getProperty("queryHisTaskListByAssignee");
			startProcess = properties.getProperty("startProcess");
			doTask = properties.getProperty("doTask");
			setVariables = properties.getProperty("setVariables");
			timeout = Integer.parseInt(properties.getProperty("timeout"));
			baseUrl = properties.getProperty("httpUrl");
			
			
			in.close();
		} catch (Exception e) {
			logger.error("初始化HttpUrl路径失败，失败信息："+e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * 将一个json字符串，转换成一个Map
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> json2Map(String json) throws Exception {
		// JavaType javaType =
		// objectMapper.getTypeFactory().constructParametricType(HashMap.class,String.class);
		return objectMapper.readValue(json, HashMap.class);
	}

	/**
	 * 将一个json字符串，转换成一个某个具体对象
	 * 
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static <T> T json2Bean(String json, T target) throws Exception {

		return (T) objectMapper.readValue(json, target.getClass());
	}

	/**
	 * 将一个json字符串，转换成一个Page对象
	 * 
	 * @param listJson
	 *            ：json字符串
	 * @param Page
	 *            ：分页类型
	 * @param target
	 *            ：目标对象
	 * @return
	 * @throws Exception
	 */
	public static <T> Page<T> json2Bean(String listJson, Page<T> page, T target)
			throws Exception {

		JavaType javaType = objectMapper.getTypeFactory()
				.constructParametricType(page.getClass(), target.getClass());
		return objectMapper.readValue(listJson, javaType);
	}

	/**
	 * 将一个json字符串，转换成一个List集合
	 * 
	 * @param listJson
	 *            ：json字符串
	 * @param list
	 *            ：集合类型
	 * @param target
	 *            ：目标对象
	 * @return
	 * @throws Exception
	 */
	public static <T> List<T> json2Bean(String listJson, List<T> list, T target)
			throws Exception {

		JavaType javaType = objectMapper.getTypeFactory()
				.constructParametricType(list.getClass(), target.getClass());
		return objectMapper.readValue(listJson, javaType);
	}

}


