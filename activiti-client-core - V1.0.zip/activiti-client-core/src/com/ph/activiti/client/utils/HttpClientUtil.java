package com.ph.activiti.client.utils;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import net.sf.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.AuthSchemes;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;

/**
 * Http请求远程 Activiti 服务工具类
 * @author yangyunyun
 *
 */
public class HttpClientUtil {
	

	private static CloseableHttpClient httpClient = HttpClients.createDefault();
	private static Logger logger = Logger.getLogger(HttpClientUtil.class);
	private static int TIMEOUT;//连接超时时间
	private static String baseUrl;//远程服务的根地址，例如："http://localhost:8081/demo/"
	private static RequestConfig requestConfig;
	
	static{
		init();
	}
	
	//初始化的时候从配置文件中获取相应数据
	private static void init(){
		TIMEOUT = Utils.timeout;
		baseUrl = Utils.baseUrl;
		
		setRequestConfig();
	}
	
	private static void setRequestConfig(){
		
		RequestConfig defaultRequestConfig = RequestConfig.custom()
	            .setCookieSpec(CookieSpecs.DEFAULT)
	            .setExpectContinueEnabled(true)
	            .setTargetPreferredAuthSchemes(Arrays.asList(AuthSchemes.NTLM, AuthSchemes.DIGEST))
	            .setProxyPreferredAuthSchemes(Arrays.asList(AuthSchemes.BASIC))
	            .build();
		
		requestConfig = RequestConfig.copy(defaultRequestConfig)
                .setSocketTimeout(TIMEOUT)
                .setConnectTimeout(TIMEOUT)
                .setConnectionRequestTimeout(TIMEOUT)
                //.setProxy(new HttpHost("myotherproxy", 8080))
                .build();
		
	}
	
	/**
	 * 远程访问
	 * @param url 
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static String httpConnect(String url,List<NameValuePair> params) throws Exception{
		
		logger.info("开始远程访问，访问url ："+baseUrl+url);
		HttpPost httpPost = new HttpPost(baseUrl+url);
		
		JSONObject json = new JSONObject();
		httpPost.setConfig(requestConfig);
		if(params != null && params.size()>0){
			httpPost.setEntity(new UrlEncodedFormEntity(params,"utf-8"));
		}
		CloseableHttpResponse response = httpClient.execute(httpPost);
		try {
			
			int statusCode = response.getStatusLine().getStatusCode();
			if(statusCode == 200){
				HttpEntity entity = response.getEntity();
				
				InputStream is = entity.getContent();
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				byte[] buffer = new byte[1024];
				int len = -1;
				while ((len = is.read(buffer)) != -1) {
					baos.write(buffer, 0, len);
				}
				String result = baos.toString();
				
				json.put("isSucceed", "1");
				json.put("msg", "交互成功！");
				json.put("data", result);
				logger.info("远程访问Activiti服务成功，访问url："+baseUrl+url);
				baos.close();
			}else{
				json.put("isSucceed", "1");
				json.put("msg", "远程访问Activiti服务失败，失败状态码："+statusCode);
				json.put("data", "");
				logger.info("远程访问Activiti服务失败，失败状态码："+statusCode+" ，访问url："+baseUrl+url);
			}
		} catch (Exception e) {
			logger.info("远程访问Activiti服务异常，异常信息："+e.getMessage());
			throw e;
		}finally{
			response.close();
		}
		return json.toString();
	}
	
	

//	private static List<HttpURLConnection> connectionList = new ArrayList<>();
//
//	private static String url = "http://localhost:8081/demo/";
//
//	/*
//	 * static{ InputStream in =
//	 * HttpClientUtil.class.getClassLoader().getResourceAsStream
//	 * ("/httpUrl.properties"); File file = new File("/httpUrl.properties"); try
//	 * { FileReader reader = new FileReader(file);
//	 * 
//	 * } catch (IOException e) { e.printStackTrace(); } }
//	 */
//
//	public static void main(String[] args) throws Exception {
//		// 1). 得到path
//		String path = url + "mvc/phProcess/queryAllProcessDefinition.do";
//		// 2). 创建URL对象
//		URL url = new URL(path);
//		// 3). 打开连接, 得到HttpURLConnection对象
//		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
//		// 4). 设置请求方式,连接超时, 读取数据超时
//		connection.setRequestMethod("POST");
//		connection.setConnectTimeout(5000);
//		connection.setReadTimeout(5000);
//		connection.setDoOutput(true);
//		connection.setDoInput(true);
//		
//		// 5). 连接服务器
//		connection.connect();
//
//		// 6). 发请求, 得到响应数据
//		// 得到输出流, 写请求体:name=Tom1&age=11
//		OutputStream os = connection.getOutputStream();
//		String data = "param=1000";
//		os.write(data.getBytes("utf-8"));
//
//		// 得到响应码, 必须是200才读取
//		int responseCode = connection.getResponseCode();
//		if (responseCode == 200) {
//			// 得到InputStream, 并读取成String
//			InputStream is = connection.getInputStream();
//			ByteArrayOutputStream baos = new ByteArrayOutputStream();
//			byte[] buffer = new byte[1024];
//			int len = -1;
//			while ((len = is.read(buffer)) != -1) {
//				baos.write(buffer, 0, len);
//			}
//			
//			String result = baos.toString();
//
//			baos.close();
//			is.close();
//
//			System.out.println(result);
//			List<ProcessDefinitionVo> list = json2Bean(result, new ArrayList<ProcessDefinitionVo>(), new ProcessDefinitionVo());
//			
//			for(ProcessDefinitionVo vo : list){
//				System.out.println(vo);
//			}
//		}
//		os.close();
//		// 7). 断开连接
//		connection.disconnect();
//	}
	

}
